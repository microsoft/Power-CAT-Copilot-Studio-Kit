"""HubSpot CRM tool handlers — Companies, Contacts, Deals, Orders, Products."""

from __future__ import annotations

import asyncio
import re
from datetime import datetime, timezone
from typing import Any

import structlog
from cachetools import TTLCache
from mcp import types
from mcp.types import TextContent

from .hubspot_client import HubSpotAPIError, HubSpotAuthError, get_client

log = structlog.get_logger("hs")


# ── Entity Schemas ────────────────────────────────────────────────────────────

_ENTITY_SCHEMAS: dict[str, dict] = {
    "Company": {
        "columns": [
            {"apiName": "name", "label": "Name"},
            {"apiName": "domain", "label": "Domain"},
            {"apiName": "type", "label": "Type"},
            {"apiName": "lifecyclestage", "label": "Stage"},
            {"apiName": "city", "label": "City"},
            {"apiName": "country", "label": "Country"},
        ],
        "hiddenColumns": [
            {"apiName": "phone", "label": "Phone"},
            {"apiName": "description", "label": "Description"},
        ],
        "filterFields": {
            "name": {"operator": "CONTAINS_TOKEN", "property": "name"},
            "domain": {"operator": "CONTAINS_TOKEN", "property": "domain"},
            "type": {"operator": "EQ", "property": "type"},
            "lifecyclestage": {"operator": "EQ", "property": "lifecyclestage"},
            "city": {"operator": "CONTAINS_TOKEN", "property": "city"},
            "country": {"operator": "CONTAINS_TOKEN", "property": "country"},
        },
        "formFields": [
            {"name": "name", "label": "Company Name", "required": True},
            {"name": "domain", "label": "Domain"},
            {"name": "type", "label": "Type", "picklist": ["PROSPECT", "PARTNER", "RESELLER", "VENDOR", "OTHER"]},
            {"name": "lifecyclestage", "label": "Lifecycle Stage", "picklist": ["subscriber", "lead", "marketingqualifiedlead", "salesqualifiedlead", "opportunity", "customer", "evangelist", "other"]},
            {"name": "city", "label": "City"},
            {"name": "phone", "label": "Phone"},
            {"name": "country", "label": "Country"},
            {"name": "description", "label": "Description", "multiline": True},
        ],
    },
    "Contact": {
        "columns": [
            {"apiName": "firstname", "label": "First Name"},
            {"apiName": "lastname", "label": "Last Name"},
            {"apiName": "email", "label": "Email"},
            {"apiName": "phone", "label": "Phone"},
            {"apiName": "jobtitle", "label": "Job Title"},
            {"apiName": "city", "label": "City"},
            {"apiName": "lifecyclestage", "label": "Lifecycle Stage"},
            {"apiName": "company", "label": "Company"},
        ],
        "hiddenColumns": [],
        "filterFields": {
            "email": {"operator": "EQ", "property": "email"},
            "lifecyclestage": {"operator": "EQ", "property": "lifecyclestage"},
            "firstname": {"operator": "CONTAINS_TOKEN", "property": "firstname"},
            "lastname": {"operator": "CONTAINS_TOKEN", "property": "lastname"},
            "jobtitle": {"operator": "CONTAINS_TOKEN", "property": "jobtitle"},
            "city": {"operator": "CONTAINS_TOKEN", "property": "city"},
            "phone": {"operator": "CONTAINS_TOKEN", "property": "phone"},
        },
        "formFields": [
            {"name": "firstname", "label": "First Name", "required": True},
            {"name": "lastname", "label": "Last Name", "required": True},
            {"name": "email", "label": "Email", "required": True},
            {"name": "phone", "label": "Phone"},
            {"name": "jobtitle", "label": "Job Title"},
            {"name": "lifecyclestage", "label": "Lifecycle Stage", "picklist": ["subscriber", "lead", "marketingqualifiedlead", "salesqualifiedlead", "opportunity", "customer", "evangelist", "other"]},
            {"name": "city", "label": "City"},
            {"name": "company_name", "label": "Company (type full name)", "fk": True},
        ],
    },
    "Deal": {
        "columns": [
               {"apiName": "dealname", "label": "Deal Name"},
               {"apiName": "amount", "label": "Amount"},
               {"apiName": "dealstage", "label": "Stage"},
               {"apiName": "pipeline", "label": "Pipeline"},
               {"apiName": "closedate", "label": "Close Date"},
               {"apiName": "company", "label": "Company"},
        ],
        "hiddenColumns": [
               {"apiName": "dealtype", "label": "Deal Type"},
               {"apiName": "description", "label": "Description"},
        ],
        "filterFields": {
               "dealname": {"operator": "CONTAINS_TOKEN", "property": "dealname"},
               "dealstage": {"operator": "EQ", "property": "dealstage"},
               "pipeline": {"operator": "EQ", "property": "pipeline"},
               "dealtype": {"operator": "EQ", "property": "dealtype"},
               "amount_min": {"operator": "GTE", "property": "amount"},
               "amount_max": {"operator": "LTE", "property": "amount"},
               "closedate": {"operator": "ON_DATE", "property": "closedate"},
        },
        "formFields": [
               {"name": "dealname", "label": "Deal Name", "required": True},
               {"name": "amount", "label": "Amount"},
               {"name": "pipeline", "label": "Pipeline", "required": True, "picklist": ["default"],
                "picklistLabels": {"default": "Sales Pipeline"}},
               {"name": "dealstage", "label": "Stage", "required": True, "picklist": [
                   "3442945774", "3442945775", "3442945776", "3442945777", "closedwon", "closedlost",
               ], "picklistLabels": {
                   "3442945774": "Lead Captured", "3442945775": "Qualified",
                   "3442945776": "Proposal Sent", "3442945777": "Negotiation",
                   "closedwon": "Closed Won", "closedlost": "Closed Lost",
               }},
               {"name": "closedate", "label": "Close Date", "inputType": "date"},
               {"name": "dealtype", "label": "Deal Type", "picklist": ["newbusiness", "existingbusiness"]},
               {"name": "description", "label": "Description", "multiline": True},
               {"name": "company_name", "label": "Company (type full name)", "fk": True},
               {"name": "contact_name", "label": "Contact (type full name)", "fk": True},
        ],
        "stageLabels": {
               "3442945774": "Lead Captured",
               "3442945775": "Qualified",
               "3442945776": "Proposal Sent",
               "3442945777": "Negotiation",
               "closedwon": "Closed Won",
               "closedlost": "Closed Lost",
        },
    },
    "Product": {
        "columns": [
            {"apiName": "name", "label": "Name"},
            {"apiName": "hs_sku", "label": "SKU"},
            {"apiName": "price", "label": "Unit Price"},
            {"apiName": "hs_status", "label": "Status"},
            {"apiName": "hs_product_type", "label": "Type"},
            {"apiName": "recurringbillingfrequency", "label": "Billing Freq"},
        ],
        "hiddenColumns": [
            {"apiName": "description", "label": "Description"},
            {"apiName": "hs_recurring_billing_period", "label": "Term"},
        ],
        "filterFields": {
            "name": {"operator": "CONTAINS_TOKEN", "property": "name"},
            "hs_sku": {"operator": "CONTAINS_TOKEN", "property": "hs_sku"},
            "hs_product_type": {"operator": "EQ", "property": "hs_product_type"},
            "hs_status": {"operator": "EQ", "property": "hs_status"},
            "recurringbillingfrequency": {"operator": "EQ", "property": "recurringbillingfrequency"},
            "price_min": {"operator": "GTE", "property": "price"},
            "price_max": {"operator": "LTE", "property": "price"},
        },
        "formFields": [
            {"name": "name", "label": "Product Name", "required": True},
            {"name": "hs_sku", "label": "SKU"},
            {"name": "price", "label": "Unit Price"},
            {"name": "hs_status", "label": "Status", "picklist": ["active", "inactive"]},
            {"name": "hs_product_type", "label": "Product Type", "picklist": ["inventory", "non_inventory", "service"]},
            {"name": "recurringbillingfrequency", "label": "Billing Frequency", "picklist": [
                "weekly", "biweekly", "monthly", "quarterly", "per_six_months",
                "annually", "per_two_years", "per_three_years", "per_four_years", "per_five_years",
            ]},
            {"name": "hs_recurring_billing_period", "label": "Term (e.g. 12 months)"},
            {"name": "description", "label": "Description", "multiline": True},
        ],
    },
    "Order": {
        "columns": [
               {"apiName": "hs_order_name", "label": "Order Name"},
               {"apiName": "hs_total_price", "label": "Total"},
               {"apiName": "hs_currency_code", "label": "Currency"},
               {"apiName": "hs_fulfillment_status", "label": "Fulfillment"},
               {"apiName": "hs_payment_status", "label": "Payment"},
               {"apiName": "hs_closed_date", "label": "Closed Date"},
               {"apiName": "contact", "label": "Contact"},
               {"apiName": "company", "label": "Company"},
               {"apiName": "deal", "label": "Deal"},
        ],
        "hiddenColumns": [
               {"apiName": "hs_source_store", "label": "Source Store"},
        ],
        "filterFields": {
               "hs_order_name": {"operator": "CONTAINS_TOKEN", "property": "hs_order_name"},
               "hs_fulfillment_status": {"operator": "EQ", "property": "hs_fulfillment_status"},
               "hs_payment_status": {"operator": "EQ", "property": "hs_payment_status"},
               "hs_currency_code": {"operator": "EQ", "property": "hs_currency_code"},
               "hs_total_price_min": {"operator": "GTE", "property": "hs_total_price"},
               "hs_total_price_max": {"operator": "LTE", "property": "hs_total_price"},
               "hs_closed_date": {"operator": "ON_DATE", "property": "hs_closed_date"},
        },
        "formFields": [
               {"name": "hs_order_name", "label": "Order Name", "required": True},
               {"name": "hs_total_price", "label": "Total Price"},
               {"name": "hs_currency_code", "label": "Currency", "picklist": ["USD", "EUR", "GBP", "CAD", "AUD", "INR"]},
               {"name": "hs_fulfillment_status", "label": "Fulfillment Status", "picklist": ["pending", "fulfilled", "shipped", "canceled"]},
               {"name": "hs_payment_status", "label": "Payment Status", "picklist": ["pending", "paid", "refunded", "failed"]},
               {"name": "hs_source_store", "label": "Source Store"},
               {"name": "company_name", "label": "Company (type full name)", "fk": True},
               {"name": "contact_name", "label": "Contact (type full name)", "fk": True},
               {"name": "deal_name", "label": "Deal (type full name)", "fk": True},
        ],
    },
}


def _get_schema(entity: str) -> dict:
    return _ENTITY_SCHEMAS[entity]


# ── Cache ─────────────────────────────────────────────────────────────────────

_caches: dict[str, TTLCache] = {}


def _get_cache(entity: str) -> TTLCache:
    if entity not in _caches:
        _caches[entity] = TTLCache(maxsize=10, ttl=90)
    return _caches[entity]


def _cache_get(key: str, entity: str) -> tuple[list | None, str | None]:
    cache = _get_cache(entity)
    entry = cache.get(key)
    if entry is not None:
        return entry["items"], entry["cached_at"]
    return None, None


def _cache_set(key: str, entity: str, items: list) -> str:
    cache = _get_cache(entity)
    cached_at = _now_iso()
    cache[key] = {"items": items, "cached_at": cached_at}
    return cached_at


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


async def _empty_list() -> list:
    """Awaitable that resolves to an empty list (placeholder for asyncio.gather)."""
    return []


def _to_hs_date(value: str) -> str:
    """Normalize a date/datetime form value to epoch milliseconds (UTC).

    HubSpot accepts epoch-ms for every date and datetime property, and a "date"
    property additionally requires the value to fall on midnight UTC. The date
    picker sends ``YYYY-MM-DD`` and the datetime-local picker sends
    ``YYYY-MM-DDTHH:MM``; both are converted here. Empty values and values that
    are already epoch-ms are passed through unchanged.
    """
    if not value:
        return value
    v = value.strip()
    if v.isdigit():
        return v
    try:
        if "T" in v:
            dt = datetime.fromisoformat(v)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
        else:
            dt = datetime.fromisoformat(v).replace(tzinfo=timezone.utc)
        return str(int(dt.timestamp() * 1000))
    except ValueError:
        return v


_WEEKLY_FREQS = {"weekly", "biweekly"}


def _term_unit_for_freq(freq: str) -> str:
    """ISO-8601 duration unit HubSpot requires for a given billing frequency.

    HubSpot rejects an order/product save unless ``hs_recurring_billing_period``
    (the term) shares the unit family of ``recurringbillingfrequency``: weeks
    (``W``) for weekly/biweekly billing, months (``M``) for everything else
    (monthly, quarterly, per_six_months, annually, per_two_years, ...).
    """
    return "W" if (freq or "").strip().lower() in _WEEKLY_FREQS else "M"


def _to_hs_duration(value: str, unit: str = "M") -> str:
    """Normalize a contract-term value to an ISO-8601 duration in ``unit``.

    HubSpot's ``hs_recurring_billing_period`` must be an ISO-8601 duration whose
    unit matches the billing frequency (weeks or months — see
    ``_term_unit_for_freq``); a bare number or a mismatched unit returns HTTP
    400. This extracts the numeric count from friendly inputs (``90``,
    ``12 months``, ``P4W``) and re-expresses it in the required ``unit``. Empty
    values and values with no digits are passed through unchanged.
    """
    if not value:
        return value
    m = re.search(r"\d+", value)
    if not m:
        return value.strip()
    return f"P{m.group(0)}{unit}"


def _friendly_product_error(exc: Exception) -> str:
    """Turn a raw HubSpot product API error into a single user-friendly sentence."""
    msg = str(exc)
    if "monthly or weekly form" in msg or (
        "recurringbillingfrequency" in msg and "hs_recurring_billing_period" in msg
    ):
        return (
            "Couldn't save the product: the Term must use the same unit as the "
            "Billing Frequency — weeks (e.g. '4 weeks') for weekly or biweekly "
            "billing, or months (e.g. '12 months') for monthly, quarterly, or "
            "annual billing."
        )
    # Strip the technical 'HubSpot API error (context, HTTP nnn): ' prefix and
    # any duplicated tail so the toast shows one clean sentence.
    detail = msg.split("): ", 1)[-1] if "): " in msg else msg
    detail = detail.split(".: ")[0].strip().rstrip(".")
    return f"Couldn't save the product: {detail}." if detail else "Couldn't save the product."




# ── Shared helpers ────────────────────────────────────────────────────────────

def _error_result(msg: str) -> types.CallToolResult:
    return types.CallToolResult(
        content=[TextContent(type="text", text=msg)],
        structuredContent={"type": "error", "message": msg},
    )


def _list_summary(entity_label: str, items: list, cache_hit: bool = False) -> str:
    count = len(items)
    suffix = " (cached)" if cache_hit else ""
    return f"{count} {entity_label}{suffix}."


def _get_list_props(entity: str) -> list[str]:
    """Property names for list + detail view (columns + hidden).

    Hidden columns (e.g. Product description/Term, Company/Deal description)
    are not shown in the table but the detail pop-up and row-level edit dialog
    read them from the same list payload, so they must be fetched here too.
    """
    cfg = _get_schema(entity)
    return [c["apiName"] for c in cfg["columns"] + cfg["hiddenColumns"]]


def _get_all_props(entity: str) -> list[str]:
    """Get all property names (list + hidden)."""
    cfg = _get_schema(entity)
    return [c["apiName"] for c in cfg["columns"] + cfg["hiddenColumns"]]


# ── Create consistency ────────────────────────────────────────────────────────
# HubSpot's CRM search index is eventually consistent: a just-created record can
# be absent from search results for a few seconds, so an immediate post-create
# list refresh may omit it and make the save look like it failed. Fetching by id
# hits the object store directly (immediately consistent), so we fetch the new
# record and prepend it when the search list left it out.

# Columns that are association-resolved, not real HubSpot properties — never
# request them via get_object (would 400).
_ASSOC_PLACEHOLDER_COLS: dict[str, set[str]] = {
    "Deal": {"company"},
    "Order": {"contact", "company", "deal"},
}


async def _fetch_created_record(client: Any, object_type: str, entity: str, new_id: Any) -> dict | None:
    skip = _ASSOC_PLACEHOLDER_COLS.get(entity, set())
    props = [p for p in _get_list_props(entity) if p not in skip]
    try:
        return await client.get_object(object_type, new_id, props)
    except Exception:
        return None


async def _ensure_created(client: Any, object_type: str, entity: str, new_id: Any, items: list) -> list:
    """Prepend the just-created record to a search-derived list if the search
    index has not caught up yet."""
    if not new_id or any(str(i.get("id")) == str(new_id) for i in items):
        return items
    rec = await _fetch_created_record(client, object_type, entity, new_id)
    return [rec, *items] if rec else items


async def _refresh_with_created(result, object_type: str, entity: str, cache_key: str, new_id: Any):
    """Post-process a delegated get-handler result so the just-created record is
    present despite search-index lag."""
    try:
        client = get_client()
        sc = result.structuredContent or {}
        items = sc.get("items", [])
        merged = await _ensure_created(client, object_type, entity, new_id, items)
        if len(merged) != len(items):
            sc["items"] = merged
            sc["total"] = len(merged)
            _cache_set(cache_key, entity, merged)
    except Exception:
        pass
    return result


# ── FK resolution helpers ─────────────────────────────────────────────────────

async def _resolve_company(client: Any, name: str) -> tuple[str | None, list[str]]:
    """Find a Company by name. Returns (id, suggestions).
    - id non-empty on exact match, suggestions = []
    - id None on miss, suggestions = up to 5 fuzzy candidates
    """
    filter_groups = [{"filters": [{"propertyName": "name", "operator": "CONTAINS_TOKEN", "value": name}]}]
    results = await client.search_objects("companies", ["name"], filter_groups=filter_groups, limit=6)
    # Check for exact match
    for r in results:
        if (r.get("name") or "").lower() == name.lower():
            return r["id"], []
    if results:
        return None, [r.get("name", "") for r in results if r.get("name")][:5]
    # No fuzzy hits — fall back to most recent
    recent = await client.search_objects("companies", ["name"], limit=5)
    return None, [r.get("name", "") for r in recent if r.get("name")]


def _company_not_found_alert(name: str, suggestions: list[str]) -> types.CallToolResult:
    """Return Company-not-found as an ALERT (non-isError) so Copilot's planner
    doesn't retry the tool call."""
    msg = f"Company '{name}' not found."
    if suggestions:
        msg += f" Did you mean: {', '.join(suggestions)}?"
    return types.CallToolResult(
        content=[TextContent(type="text", text=msg)],
        structuredContent={
            "type": "alert",
            "level": "warning",
            "isError": True,
            "title": f"Company '{name}' not found",
            "message": msg,
            "suggestions": suggestions,
            "field": "company_name",
        },
    )


async def _resolve_contact(client: Any, name: str) -> tuple[str | None, list[str]]:
    """Find a Contact by name (first+last). Returns (id, suggestions)."""
    parts = name.strip().split(None, 1)
    first = parts[0] if parts else name
    filter_groups = [{"filters": [{"propertyName": "firstname", "operator": "CONTAINS_TOKEN", "value": first}]}]
    results = await client.search_objects("contacts", ["firstname", "lastname", "email"], filter_groups=filter_groups, limit=6)
    # Check for exact match on full name
    for r in results:
        full = f"{r.get('firstname', '')} {r.get('lastname', '')}".strip()
        if full.lower() == name.strip().lower():
            return r["id"], []
    if results:
        return None, [f"{r.get('firstname', '')} {r.get('lastname', '')}".strip() for r in results if r.get("firstname")][:5]
    recent = await client.search_objects("contacts", ["firstname", "lastname"], limit=5)
    return None, [f"{r.get('firstname', '')} {r.get('lastname', '')}".strip() for r in recent if r.get("firstname")]


def _contact_not_found_alert(name: str, suggestions: list[str]) -> types.CallToolResult:
    """Return Contact-not-found as an ALERT."""
    msg = f"Contact '{name}' not found."
    if suggestions:
        msg += f" Did you mean: {', '.join(suggestions)}?"
    return types.CallToolResult(
        content=[TextContent(type="text", text=msg)],
        structuredContent={
            "type": "alert",
            "level": "warning",
            "isError": True,
            "title": f"Contact '{name}' not found",
            "message": msg,
            "suggestions": suggestions,
            "field": "contact_name",
        },
    )


async def _resolve_deal(client: Any, name: str) -> tuple[str | None, list[str]]:
    """Find a Deal by name. Returns (id, suggestions)."""
    filter_groups = [{"filters": [{"propertyName": "dealname", "operator": "CONTAINS_TOKEN", "value": name}]}]
    results = await client.search_objects("deals", ["dealname"], filter_groups=filter_groups, limit=6)
    for r in results:
        if (r.get("dealname") or "").lower() == name.lower():
            return r["id"], []
    if results:
        return None, [r.get("dealname", "") for r in results if r.get("dealname")][:5]
    recent = await client.search_objects("deals", ["dealname"], limit=5)
    return None, [r.get("dealname", "") for r in recent if r.get("dealname")]


def _deal_not_found_alert(name: str, suggestions: list[str]) -> types.CallToolResult:
    """Return Deal-not-found as an ALERT."""
    msg = f"Deal '{name}' not found."
    if suggestions:
        msg += f" Did you mean: {', '.join(suggestions)}?"
    return types.CallToolResult(
        content=[TextContent(type="text", text=msg)],
        structuredContent={
            "type": "alert",
            "level": "warning",
            "isError": True,
            "title": f"Deal '{name}' not found",
            "message": msg,
            "suggestions": suggestions,
            "field": "deal_name",
        },
    )


def _empty_list_on_not_found(result_type: str, schema: Any, alert: types.CallToolResult) -> types.CallToolResult:
    """Render an empty entity widget (correct list type) instead of a standalone
    alert widget when a FK filter target is not found. The "not found / did you
    mean" text is surfaced in chat (per instructions), not in a separate widget."""
    notice = alert.content[0].text if alert.content else "Not found."
    return types.CallToolResult(
        content=[TextContent(type="text", text=notice)],
        structuredContent={
            "type": result_type, "items": [], "total": 0,
            "_schema": schema, "_cache": {"hit": False, "cached_at": _now_iso()},
        },
    )


def _expand_filter(fdef: dict, value: str) -> list[dict]:
    """Expand one filterField def + value into HubSpot Search API filter dicts.

    Shared by entity filtering (``_build_filter_groups``) and activity filtering
    (``hs__get_activities`` Branch 4) so both apply identical operator conventions:
      - CONTAINS_TOKEN -> wrapped ``*value*`` for substring ("like")
      - ON_DATE        -> expanded to a same-day GTE/LTE range so it matches an
                          exact calendar day for both date and datetime properties
                          (ON_DATE is not a real HubSpot operator on its own)
      - anything else  -> emitted as-is (EQ / GTE / LTE / ...)
    """
    op = fdef["operator"]
    prop = fdef["property"]
    if op == "CONTAINS_TOKEN":
        v = value if "*" in value else f"*{value}*"
        return [{"propertyName": prop, "operator": op, "value": v}]
    if op == "ON_DATE":
        start = _to_hs_date(value)
        try:
            end = str(int(start) + 86_400_000 - 1)
        except (TypeError, ValueError):
            start = end = value
        return [
            {"propertyName": prop, "operator": "GTE", "value": start},
            {"propertyName": prop, "operator": "LTE", "value": end},
        ]
    return [{"propertyName": prop, "operator": op, "value": value}]


def _build_filter_groups(entity: str, params: dict[str, str]) -> list[dict] | None:
    """Build HubSpot Search API filterGroups from provided params.

    Operator conventions by field type:
      - text     -> CONTAINS_TOKEN, wrapped as ``*value*`` for substring ("like")
      - picklist -> EQ (exact)
      - number   -> GTE / LTE via ``*_min`` / ``*_max`` param pairs (>= / <=)
      - date     -> ON_DATE, expanded to a same-day GTE/LTE range so it matches
                    an exact calendar day for both date and datetime properties
    """
    cfg = _get_schema(entity)
    filter_defs = cfg.get("filterFields", {})
    filters: list[dict] = []
    for param_name, value in params.items():
        if not value:
            continue
        fdef = filter_defs.get(param_name)
        if not fdef:
            continue
        filters.extend(_expand_filter(fdef, value))
    if not filters:
        return None
    return [{"filters": filters}]


def _filter_signature(params: dict[str, str]) -> str:
    """Create a cache key from non-empty filter params."""
    parts = sorted(f"{k}={v}" for k, v in params.items() if v)
    return "|".join(parts)


# ── Companies tools ───────────────────────────────────────────────────────────

async def hs__get_companies(
    company_id: str = "",
    name: str = "",
    domain: str = "",
    type: str = "",
    lifecyclestage: str = "",
    city: str = "",
    country: str = "",
    action: str = "",
    refresh: bool = False,
) -> types.CallToolResult:
    """Get companies. Branches: id+edit→form, id→list-of-one, filters→filtered, bare→top 5."""
    log.info("hs__get_companies", company_id=company_id, action=action,
             name=name, domain=domain, type=type, lifecyclestage=lifecyclestage,
             city=city, country=country, refresh=refresh)

    cfg = _get_schema("Company")

    # Branch 1a — action="create" → blank create form (prefill from filters)
    if action == "create":
        prefill = {field["name"]: "" for field in cfg["formFields"]}
        # Allow prefill from query params
        if name:
            prefill["name"] = name
        if domain:
            prefill["domain"] = domain
        if type:
            prefill["type"] = type
        if lifecyclestage:
            prefill["lifecyclestage"] = lifecyclestage
        if city:
            prefill["city"] = city
        if country:
            prefill["country"] = country
        return types.CallToolResult(
            content=[TextContent(type="text", text="Opening create form for a new company.")],
            structuredContent={
                "type": "form", "entity": "company", "mode": "create",
                "recordId": "", "prefill": prefill,
                "_schema": cfg,
            },
        )

    # Branch 1b — id + action="edit"/"change" → prefilled edit form
    if company_id and action in ("edit", "change"):
        try:
            client = get_client()
            record = await client.get_object("companies", company_id, _get_all_props("Company"))
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except HubSpotAPIError as exc:
            return _error_result(f"Company {company_id} not found: {exc}")
        except Exception as exc:
            return _error_result(f"Error looking up company: {exc}")

        prefill = {field["name"]: record.get(field["name"], "") or "" for field in cfg["formFields"]}
        return types.CallToolResult(
            content=[TextContent(type="text", text=f"Opening edit form for company: {record.get('name', company_id)}.")],
            structuredContent={
                "type": "form", "entity": "company", "mode": "edit",
                "recordId": record.get("id", company_id), "prefill": prefill,
                "_schema": cfg,
            },
        )

    # Branch 2 — id alone → list-of-one
    if company_id:
        try:
            client = get_client()
            record = await client.get_object("companies", company_id, _get_list_props("Company"))
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except HubSpotAPIError as exc:
            return _error_result(f"Company {company_id} not found: {exc}")
        except Exception as exc:
            return _error_result(f"Error fetching company: {exc}")

        items = [record]
        return types.CallToolResult(
            content=[TextContent(type="text", text=_list_summary("company(ies)", items))],
            structuredContent={
                "type": "companies", "total": len(items), "items": items,
                "_schema": cfg, "_cache": {"hit": False, "cached_at": _now_iso()},
            },
        )

    # Branch 3 — filter-based or bare list
    filter_params = {
        "name": name, "domain": domain, "type": type,
        "lifecyclestage": lifecyclestage, "city": city, "country": country,
    }
    filter_groups = _build_filter_groups("Company", filter_params)
    has_filters = filter_groups is not None

    # Cache lookup
    filter_sig = _filter_signature(filter_params)
    cache_key = f"companies:{filter_sig}" if filter_sig else "companies"
    if not refresh:
        cached_items, cached_at = _cache_get(cache_key, "Company")
        if cached_items is not None:
            return types.CallToolResult(
                content=[TextContent(type="text", text=_list_summary("company(ies)", cached_items, cache_hit=True))],
                structuredContent={
                    "type": "companies", "total": len(cached_items), "items": cached_items,
                    "_schema": cfg, "_cache": {"hit": True, "cached_at": cached_at},
                },
            )

    try:
        client = get_client()
        props = _get_list_props("Company")
        items = await client.search_objects("companies", props, filter_groups=filter_groups, limit=10)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to fetch companies: {exc}")
    except Exception as exc:
        return _error_result(f"Error fetching companies: {exc}")

    cached_at = _cache_set(cache_key, "Company", items)
    return types.CallToolResult(
        content=[TextContent(type="text", text=_list_summary("company(ies)", items))],
        structuredContent={
            "type": "companies", "total": len(items), "items": items,
            "_schema": cfg, "_cache": {"hit": False, "cached_at": cached_at},
        },
    )


async def hs__create_company(
    name: str,
    domain: str = "",
    type: str = "",
    lifecyclestage: str = "",
    city: str = "",
    phone: str = "",
    country: str = "",
    description: str = "",
) -> types.CallToolResult:
    """Create a new Company in HubSpot CRM. Requires name. Returns updated list."""
    log.info("hs__create_company", name=name, domain=domain, type=type,
             lifecyclestage=lifecyclestage, city=city)

    props: dict[str, Any] = {"name": name}
    if domain:
        props["domain"] = domain
    if type:
        props["type"] = type
    if lifecyclestage:
        props["lifecyclestage"] = lifecyclestage
    if city:
        props["city"] = city
    if phone:
        props["phone"] = phone
    if country:
        props["country"] = country
    if description:
        props["description"] = description

    try:
        client = get_client()
        new_id = await client.create_object("companies", props)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to create company: {exc}")
    except Exception as exc:
        return _error_result(f"Unexpected error creating company: {exc}")

    # Refresh list
    try:
        items = await client.search_objects("companies", _get_list_props("Company"), limit=10)
        items = await _ensure_created(client, "companies", "Company", new_id, items)
    except Exception:
        items = []

    cfg = _get_schema("Company")
    _cache_set("companies", "Company", items)
    return types.CallToolResult(
        content=[TextContent(type="text", text=f"Company '{name}' created (Id: {new_id}).")],
        structuredContent={
            "type": "companies", "total": len(items), "items": items,
            "_schema": cfg, "_createdId": new_id,
            "_cache": {"hit": False, "cached_at": _now_iso()},
        },
    )


async def hs__update_company(
    company_id: str,
    name: str = "",
    domain: str = "",
    type: str = "",
    lifecyclestage: str = "",
    city: str = "",
    phone: str = "",
    country: str = "",
    description: str = "",
) -> types.CallToolResult:
    """Update an existing Company by id. Only provided fields are updated."""
    log.info("hs__update_company", company_id=company_id, name=name, domain=domain)

    props: dict[str, Any] = {}
    if name:
        props["name"] = name
    if domain:
        props["domain"] = domain
    if type:
        props["type"] = type
    if lifecyclestage:
        props["lifecyclestage"] = lifecyclestage
    if city:
        props["city"] = city
    if phone:
        props["phone"] = phone
    if country:
        props["country"] = country
    if description:
        props["description"] = description

    if not props:
        return _error_result("No fields provided to update.")

    try:
        client = get_client()
        await client.update_object("companies", company_id, props)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to update company: {exc}")
    except Exception as exc:
        return _error_result(f"Unexpected error updating company: {exc}")

    # Refresh list
    try:
        items = await client.search_objects("companies", _get_list_props("Company"), limit=10)
    except Exception:
        items = []

    cfg = _get_schema("Company")
    _cache_set("companies", "Company", items)
    return types.CallToolResult(
        content=[TextContent(type="text", text=f"Company {company_id} updated.")],
        structuredContent={
            "type": "companies", "total": len(items), "items": items,
            "_schema": cfg, "_updatedId": company_id,
            "_cache": {"hit": False, "cached_at": _now_iso()},
        },
    )


# ── Generic associations tool ─────────────────────────────────────────────────

# HubSpot default support-pipeline ticket stage IDs → friendly labels.
_TICKET_STAGE_LABELS: dict[str, str] = {
    "1": "New",
    "2": "Waiting on contact",
    "3": "Waiting on us",
    "4": "Closed",
}


def _ticket_stage_label(stage_id: str) -> str:
    """Convert a ticket pipeline stage ID to a human-readable label."""
    return _TICKET_STAGE_LABELS.get(stage_id, stage_id)


_ASSOC_CONFIG: dict[str, dict] = {
    "contacts": {
        "props": ["firstname", "lastname", "email", "phone", "lifecyclestage"],
        "map": lambda r: {
            "id": r.get("id", ""),
            "firstname": r.get("firstname", "") or "",
            "lastname": r.get("lastname", "") or "",
            "email": r.get("email", "") or "",
            "phone": r.get("phone", "") or "",
            "lifecyclestage": r.get("lifecyclestage", "") or "",
        },
        "label": "contact",
    },
    "deals": {
        "props": ["dealname", "amount", "dealstage", "closedate", "pipeline"],
        "map": lambda r: {
            "id": r.get("id", ""),
            "dealname": r.get("dealname", "") or "",
            "amount": r.get("amount", "") or "",
            "dealstage": _deal_stage_label(r.get("dealstage", "") or ""),
            "closedate": r.get("closedate", "") or "",
            "pipeline": r.get("pipeline", "") or "",
        },
        "label": "deal",
    },
    "tickets": {
        "props": ["subject", "hs_pipeline_stage", "hs_ticket_priority", "hs_ticket_category"],
        "map": lambda r: {
            "id": r.get("id", ""),
            "subject": r.get("subject", "") or "",
            "status": _ticket_stage_label(r.get("hs_pipeline_stage", "") or ""),
            "priority": r.get("hs_ticket_priority", "") or "",
            "category": r.get("hs_ticket_category", "") or "",
        },
        "label": "ticket",
    },
    "companies": {
        "props": ["name", "domain", "city", "lifecyclestage"],
        "map": lambda r: {
            "id": r.get("id", ""),
            "name": r.get("name", "") or "",
            "domain": r.get("domain", "") or "",
            "city": r.get("city", "") or "",
            "lifecyclestage": r.get("lifecyclestage", "") or "",
        },
        "label": "company",
    },
    "line_items": {
        "props": ["name", "quantity", "price", "amount", "hs_sku"],
        "map": lambda r: {
            "id": r.get("id", ""),
            "name": r.get("name", "") or "",
            "quantity": r.get("quantity", "") or "",
            "price": r.get("price", "") or "",
            "amount": r.get("amount", "") or "",
            "sku": r.get("hs_sku", "") or "",
        },
        "label": "line item",
    },
}

_VALID_SOURCES = {"companies", "contacts", "deals", "orders"}
_VALID_TARGETS = {"companies", "contacts", "deals", "tickets", "line_items"}


async def hs__get_associations(
    entity_type: str,
    entity_id: str,
    association_type: str,
    refresh: bool = False,
) -> types.CallToolResult:
    """Get records associated to an entity via HubSpot Associations API.

    entity_type: source object (companies, contacts).
    entity_id:   HubSpot record id.
    association_type: target object (contacts, deals, tickets, companies).
    """
    log.info("hs__get_associations", entity_type=entity_type, entity_id=entity_id,
             association_type=association_type, refresh=refresh)

    if not entity_id:
        return _error_result("entity_id is required.")
    if entity_type not in _VALID_SOURCES:
        return _error_result(f"entity_type must be one of {sorted(_VALID_SOURCES)}.")
    if association_type not in _VALID_TARGETS or association_type == entity_type:
        return _error_result(f"association_type must be one of {sorted(_VALID_TARGETS - {entity_type})}.")

    cfg = _ASSOC_CONFIG[association_type]

    try:
        client = get_client()
        assoc_ids = await client.get_associated_ids(entity_type, entity_id, association_type)
        records = await client.batch_read(association_type, assoc_ids, cfg["props"])
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to fetch {association_type}: {exc}")
    except Exception as exc:
        return _error_result(f"Error fetching {association_type}: {exc}")

    items = [cfg["map"](r) for r in records]
    return types.CallToolResult(
        content=[TextContent(type="text", text=f"Showing {len(items)} {cfg['label']}(s).")],
        structuredContent={
            "type": f"{entity_type}_{association_type}",
            "entity_id": entity_id,
            "items": items,
            "total": len(items),
        },
    )


# ── Contacts tools ────────────────────────────────────────────────────────────

async def hs__get_contacts(
    contact_id: str = "",
    firstname: str = "",
    lastname: str = "",
    email: str = "",
    company_name: str = "",
    lifecyclestage: str = "",
    jobtitle: str = "",
    city: str = "",
    phone: str = "",
    action: str = "",
    refresh: bool = False,
) -> types.CallToolResult:
    """Get contacts. Branches: action=create→form, id+edit→form, id→single, company_name→FK filter, filters→list."""
    log.info("hs__get_contacts", contact_id=contact_id, action=action,
             firstname=firstname, lastname=lastname, email=email,
             company_name=company_name, lifecyclestage=lifecyclestage,
             jobtitle=jobtitle, city=city, phone=phone, refresh=refresh)

    cfg = _get_schema("Contact")

    # Branch 1 — action="create" → blank form
    if action == "create":
        prefill = {field["name"]: "" for field in cfg["formFields"]}
        if firstname:
            prefill["firstname"] = firstname
        if lastname:
            prefill["lastname"] = lastname
        if email:
            prefill["email"] = email
        if phone:
            prefill["phone"] = phone
        if jobtitle:
            prefill["jobtitle"] = jobtitle
        if lifecyclestage:
            prefill["lifecyclestage"] = lifecyclestage
        if city:
            prefill["city"] = city
        if company_name:
            prefill["company_name"] = company_name
        return types.CallToolResult(
            content=[TextContent(type="text", text="Opening create form for a new contact.")],
            structuredContent={
                "type": "form", "entity": "contact", "mode": "create",
                "recordId": "", "prefill": prefill,
                "_schema": cfg,
            },
        )

    # Branch 2 — id + action="edit" → prefilled edit form
    if contact_id and action in ("edit", "change"):
        try:
            client = get_client()
            record = await client.get_object("contacts", contact_id, _get_all_props("Contact"))
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except HubSpotAPIError as exc:
            return _error_result(f"Contact {contact_id} not found: {exc}")
        except Exception as exc:
            return _error_result(f"Error looking up contact: {exc}")

        prefill = {field["name"]: record.get(field["name"], "") or "" for field in cfg["formFields"] if field["name"] != "company_name"}
        # Resolve primary company name for FK field
        try:
            co_ids = await client.get_associated_ids("contacts", contact_id, "companies")
            if co_ids:
                cos = await client.batch_read("companies", co_ids[:1], ["name"])
                prefill["company_name"] = cos[0].get("name", "") if cos else ""
            else:
                prefill["company_name"] = ""
        except Exception:
            prefill["company_name"] = ""

        return types.CallToolResult(
            content=[TextContent(type="text", text=f"Opening edit form for contact: {record.get('firstname', '')} {record.get('lastname', '')}.")],
            structuredContent={
                "type": "form", "entity": "contact", "mode": "edit",
                "recordId": record.get("id", contact_id), "prefill": prefill,
                "_schema": cfg,
            },
        )

    # Branch 3 — id alone → single record
    if contact_id:
        try:
            client = get_client()
            record = await client.get_object("contacts", contact_id, _get_list_props("Contact"))
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except HubSpotAPIError as exc:
            return _error_result(f"Contact {contact_id} not found: {exc}")
        except Exception as exc:
            return _error_result(f"Error fetching contact: {exc}")

        items = [record]
        return types.CallToolResult(
            content=[TextContent(type="text", text=_list_summary("contact(s)", items))],
            structuredContent={
                "type": "contacts", "total": len(items), "items": items,
                "_schema": cfg, "_cache": {"hit": False, "cached_at": _now_iso()},
            },
        )

    # Branch 4 — FK filter: company_name → search companies → get associated contacts
    if company_name:
        try:
            client = get_client()
            # Find companies matching name
            co_filter = [{"filters": [{"propertyName": "name", "operator": "CONTAINS_TOKEN", "value": company_name}]}]
            companies = await client.search_objects("companies", ["name"], filter_groups=co_filter, limit=5)
            if not companies:
                return types.CallToolResult(
                    content=[TextContent(type="text", text=f"No company found matching '{company_name}'.")],
                    structuredContent={"type": "contacts", "total": 0, "items": [], "_schema": cfg, "_cache": {"hit": False, "cached_at": _now_iso()}},
                )
            # Gather all associated contact IDs
            all_contact_ids: list[str] = []
            for co in companies:
                co_id = co.get("id", "")
                if co_id:
                    ids = await client.get_associated_ids("companies", co_id, "contacts")
                    all_contact_ids.extend(ids)
            # Deduplicate
            all_contact_ids = list(dict.fromkeys(all_contact_ids))[:20]
            if not all_contact_ids:
                return types.CallToolResult(
                    content=[TextContent(type="text", text=f"No contacts found for '{company_name}'.")],
                    structuredContent={"type": "contacts", "total": 0, "items": [], "_schema": cfg, "_cache": {"hit": False, "cached_at": _now_iso()}},
                )
            props = _get_list_props("Contact")
            items = await client.batch_read("contacts", all_contact_ids, props)
            # Add company name to each contact
            for item in items:
                item["company"] = companies[0].get("name", "")
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except HubSpotAPIError as exc:
            return _error_result(f"Failed to fetch contacts for '{company_name}': {exc}")
        except Exception as exc:
            return _error_result(f"Error fetching contacts: {exc}")

        cached_at = _cache_set(f"contacts:company={company_name}", "Contact", items)
        return types.CallToolResult(
            content=[TextContent(type="text", text=_list_summary("contact(s)", items))],
            structuredContent={
                "type": "contacts", "total": len(items), "items": items,
                "_schema": cfg, "_cache": {"hit": False, "cached_at": cached_at},
            },
        )

    # Branch 5 — property-based filters or bare list
    filter_params = {
        "firstname": firstname, "lastname": lastname,
        "email": email, "lifecyclestage": lifecyclestage,
        "jobtitle": jobtitle, "city": city, "phone": phone,
    }
    filter_groups = _build_filter_groups("Contact", filter_params)

    filter_sig = _filter_signature(filter_params)
    cache_key = f"contacts:{filter_sig}" if filter_sig else "contacts"
    if not refresh:
        cached_items, cached_at = _cache_get(cache_key, "Contact")
        if cached_items is not None:
            return types.CallToolResult(
                content=[TextContent(type="text", text=_list_summary("contact(s)", cached_items, cache_hit=True))],
                structuredContent={
                    "type": "contacts", "total": len(cached_items), "items": cached_items,
                    "_schema": cfg, "_cache": {"hit": True, "cached_at": cached_at},
                },
            )

    try:
        client = get_client()
        props = _get_list_props("Contact")
        items = await client.search_objects("contacts", props, filter_groups=filter_groups, limit=10)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to fetch contacts: {exc}")
    except Exception as exc:
        return _error_result(f"Error fetching contacts: {exc}")

    # Resolve company names via associations (best-effort)
    try:
        for item in items:
            co_ids = await client.get_associated_ids("contacts", item["id"], "companies")
            if co_ids:
                cos = await client.batch_read("companies", co_ids[:1], ["name"])
                item["company"] = cos[0].get("name", "") if cos else ""
            else:
                item["company"] = ""
    except Exception:
        pass  # company resolution is best-effort

    cached_at = _cache_set(cache_key, "Contact", items)
    return types.CallToolResult(
        content=[TextContent(type="text", text=_list_summary("contact(s)", items))],
        structuredContent={
            "type": "contacts", "total": len(items), "items": items,
            "_schema": cfg, "_cache": {"hit": False, "cached_at": cached_at},
        },
    )


async def hs__create_contact(
    firstname: str,
    lastname: str,
    email: str,
    phone: str = "",
    jobtitle: str = "",
    lifecyclestage: str = "",
    city: str = "",
    company_name: str = "",
) -> types.CallToolResult:
    """Create a new Contact in HubSpot CRM. Optionally associate to a company by name.
    Returns alert with suggestions if company_name doesn't match."""
    log.info("hs__create_contact", firstname=firstname, lastname=lastname,
             email=email, company_name=company_name)

    props: dict[str, Any] = {"firstname": firstname, "lastname": lastname, "email": email}
    if phone:
        props["phone"] = phone
    if jobtitle:
        props["jobtitle"] = jobtitle
    if lifecyclestage:
        props["lifecyclestage"] = lifecyclestage
    if city:
        props["city"] = city

    try:
        client = get_client()

        # Resolve FK BEFORE creating — alert pattern
        resolved_company_id: str | None = None
        if company_name:
            resolved_company_id, suggestions = await _resolve_company(client, company_name)
            if not resolved_company_id:
                return _company_not_found_alert(company_name, suggestions)

        new_id = await client.create_object("contacts", props)

        # Associate to resolved company
        if resolved_company_id:
            await client.create_association("contacts", new_id, "companies", resolved_company_id)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to create contact: {exc}")
    except Exception as exc:
        return _error_result(f"Error creating contact: {exc}")

    # Return refreshed contacts list
    _get_cache("Contact").clear()
    return await hs__get_contacts(refresh=True)


async def hs__update_contact(
    contact_id: str,
    firstname: str = "",
    lastname: str = "",
    email: str = "",
    phone: str = "",
    jobtitle: str = "",
    lifecyclestage: str = "",
    city: str = "",
) -> types.CallToolResult:
    """Update an existing Contact in HubSpot CRM by its record Id."""
    log.info("hs__update_contact", contact_id=contact_id, firstname=firstname,
             lastname=lastname, email=email)

    if not contact_id:
        return _error_result("contact_id is required.")

    updates: dict[str, Any] = {}
    if firstname:
        updates["firstname"] = firstname
    if lastname:
        updates["lastname"] = lastname
    if email:
        updates["email"] = email
    if phone:
        updates["phone"] = phone
    if jobtitle:
        updates["jobtitle"] = jobtitle
    if lifecyclestage:
        updates["lifecyclestage"] = lifecyclestage
    if city:
        updates["city"] = city

    if not updates:
        return _error_result("No fields to update.")

    try:
        client = get_client()
        await client.update_object("contacts", contact_id, updates)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to update contact: {exc}")
    except Exception as exc:
        return _error_result(f"Error updating contact: {exc}")

    _get_cache("Contact").clear()
    return await hs__get_contacts(refresh=True)


# ── Deals tools ───────────────────────────────────────────────────────────────

def _deal_stage_label(stage_id: str) -> str:
    """Convert pipeline stage ID to human-readable label."""
    labels = _get_schema("Deal").get("stageLabels", {})
    return labels.get(stage_id, stage_id)


async def hs__get_deals(
    deal_id: str = "",
    dealname: str = "",
    dealstage: str = "",
    pipeline: str = "",
    dealtype: str = "",
    amount: str = "",
    amount_min: str = "",
    amount_max: str = "",
    closedate: str = "",
    company_name: str = "",
    contact_name: str = "",
    description: str = "",
    action: str = "",
    refresh: bool = False,
) -> types.CallToolResult:
    """Get deals from HubSpot CRM."""
    log.info("hs__get_deals", deal_id=deal_id, action=action, dealname=dealname,
             dealstage=dealstage, pipeline=pipeline, amount=amount, amount_min=amount_min,
             amount_max=amount_max, closedate=closedate, company_name=company_name, refresh=refresh)

    schema = _get_schema("Deal")

    # ── Branch: blank create form ────────────────────────────────────────────
    if action == "create":
        prefill = {field["name"]: "" for field in schema["formFields"]}
        if dealname:
            prefill["dealname"] = dealname
        if pipeline:
            prefill["pipeline"] = pipeline
        if dealstage:
            prefill["dealstage"] = dealstage
        if dealtype:
            prefill["dealtype"] = dealtype
        if amount:
            prefill["amount"] = amount
        if closedate:
            prefill["closedate"] = closedate
        if company_name:
            prefill["company_name"] = company_name
        if contact_name:
            prefill["contact_name"] = contact_name
        if description:
            prefill["description"] = description
        return types.CallToolResult(
            content=[TextContent(type="text", text="Opening deal create form.")],
            structuredContent={
                "type": "form",
                "entity": "deal",
                "mode": "create",
                "recordId": "",
                "prefill": prefill,
                "_schema": schema,
            },
        )

    # ── Branch: single record / edit form ────────────────────────────────────
    if deal_id:
        try:
            client = get_client()
            record = await client.get_object("deals", deal_id, _get_all_props("Deal"))
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except HubSpotAPIError as exc:
            return _error_result(f"Failed to fetch deal: {exc}")
        except Exception as exc:
            return _error_result(f"Error fetching deal: {exc}")

        if not record:
            return _error_result(f"Deal {deal_id} not found.")

        # Resolve associated company name
        try:
            co_ids = await client.get_associated_ids("deals", deal_id, "companies")
            if co_ids:
                cos = await client.batch_read("companies", co_ids[:1], ["name"])
                record["company"] = cos[0].get("name", "") if cos else ""
            else:
                record["company"] = ""
        except Exception:
            record["company"] = ""

        # Convert stage ID to label for display
        record["dealstage_label"] = _deal_stage_label(record.get("dealstage", ""))

        if action == "edit":
            return types.CallToolResult(
                content=[TextContent(type="text", text=f"Opening edit form for deal '{record.get('dealname', '')}'.")],
                structuredContent={
                    "type": "form",
                    "entity": "deal",
                    "mode": "edit",
                    "recordId": deal_id,
                    "prefill": record,
                    "_schema": schema,
                },
            )

        return types.CallToolResult(
            content=[TextContent(type="text", text=f"Deal: {record.get('dealname', '')}.")],
            structuredContent={
                "type": "deals",
                "items": [record],
                "total": 1,
                "_schema": schema,
            },
        )

    # ── Branch: FK filter by company_name ────────────────────────────────────
    if company_name:
        try:
            client = get_client()
            co_id, suggestions = await _resolve_company(client, company_name)
            if not co_id:
                return _empty_list_on_not_found("deals", schema, _company_not_found_alert(company_name, suggestions))
            deal_ids = await client.get_associated_ids("companies", co_id, "deals")
            if not deal_ids:
                return types.CallToolResult(
                    content=[TextContent(type="text", text=f"No deals found for company '{company_name}'.")],
                    structuredContent={"type": "deals", "items": [], "total": 0, "_schema": schema},
                )
            props = _get_list_props("Deal")
            items = await client.batch_read("deals", deal_ids, [p for p in props if p != "company"])
            # Attach company name and stage labels
            for item in items:
                item["company"] = company_name
                item["dealstage_label"] = _deal_stage_label(item.get("dealstage", ""))
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except Exception as exc:
            return _error_result(f"Error fetching deals by company: {exc}")

        cached_at = _cache_set(f"deals_co_{company_name}", "Deal", items)
        return types.CallToolResult(
            content=[TextContent(type="text", text=f"Showing {len(items)} deal(s) for '{company_name}'.")],
            structuredContent={
                "type": "deals",
                "items": items,
                "total": len(items),
                "_schema": schema,
                "_cache": {"hit": False, "cached_at": cached_at},
            },
        )

    # ── Branch: list / filter ────────────────────────────────────────────────
    filter_params = {k: v for k, v in {"dealname": dealname, "dealstage": dealstage, "pipeline": pipeline, "dealtype": dealtype, "amount_min": amount_min, "amount_max": amount_max, "closedate": closedate}.items() if v}
    filter_sig = _filter_signature(filter_params)
    cache_key = f"deals_{filter_sig}" if filter_sig else "deals_all"

    if not refresh:
        cached_items, cached_at = _cache_get(cache_key, "Deal")
        if cached_items is not None:
            return types.CallToolResult(
                content=[TextContent(type="text", text=_list_summary("deal(s)", cached_items, cache_hit=True))],
                structuredContent={
                    "type": "deals",
                    "items": cached_items,
                    "total": len(cached_items),
                    "_schema": schema,
                    "_cache": {"hit": True, "cached_at": cached_at},
                },
            )

    try:
        client = get_client()
        filter_groups = _build_filter_groups("Deal", filter_params) if filter_params else None
        props = _get_list_props("Deal")
        results = await client.search_objects("deals", [p for p in props if p != "company"], filter_groups=filter_groups, limit=10)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to search deals: {exc}")
    except Exception as exc:
        return _error_result(f"Error searching deals: {exc}")

    # Resolve company names for all deals in a couple of batch calls instead
    # of two sequential calls per deal.
    items = []
    for r in results:
        item = {p: r.get(p, "") or "" for p in props if p != "company"}
        item["id"] = r.get("id", "")
        item["dealstage_label"] = _deal_stage_label(item.get("dealstage", ""))
        item["company"] = ""
        items.append(item)

    deal_ids_list = [i["id"] for i in items if i["id"]]
    if deal_ids_list:
        try:
            co_map = await client.batch_get_associations("deals", "companies", deal_ids_list)
            co_ids = list({v[0] for v in co_map.values() if v})
            cos = await client.batch_read("companies", co_ids, ["name"]) if co_ids else []
            co_names = {c["id"]: c.get("name", "") for c in cos}
            for item in items:
                if co_map.get(item["id"]):
                    item["company"] = co_names.get(co_map[item["id"]][0], "")
        except Exception:
            pass

    cached_at = _cache_set(cache_key, "Deal", items)
    return types.CallToolResult(
        content=[TextContent(type="text", text=_list_summary("deal(s)", items))],
        structuredContent={
            "type": "deals",
            "items": items,
            "total": len(items),
            "_schema": schema,
            "_cache": {"hit": False, "cached_at": cached_at},
        },
    )


async def hs__create_deal(
    dealname: str = "",
    amount: str = "",
    pipeline: str = "default",
    dealstage: str = "",
    closedate: str = "",
    dealtype: str = "",
    description: str = "",
    company_name: str = "",
    contact_name: str = "",
) -> types.CallToolResult:
    """Create a new Deal in HubSpot CRM."""
    log.info("hs__create_deal", dealname=dealname, dealstage=dealstage, company_name=company_name)
    if not dealname:
        return _error_result("dealname is required.")
    if not dealstage:
        return _error_result("dealstage is required.")

    # Resolve company FK
    company_id: str | None = None
    if company_name:
        try:
            client = get_client()
            company_id, suggestions = await _resolve_company(client, company_name)
            if not company_id:
                return _company_not_found_alert(company_name, suggestions)
        except Exception as exc:
            return _error_result(f"Error resolving company: {exc}")

    # Resolve contact FK
    contact_id: str | None = None
    if contact_name:
        try:
            client = get_client()
            contact_id, suggestions = await _resolve_contact(client, contact_name)
            if not contact_id:
                return _contact_not_found_alert(contact_name, suggestions)
        except Exception as exc:
            return _error_result(f"Error resolving contact: {exc}")

    props = {"dealname": dealname, "pipeline": pipeline or "default", "dealstage": dealstage}
    if amount:
        props["amount"] = amount
    if closedate:
        props["closedate"] = _to_hs_date(closedate)
    if dealtype:
        props["dealtype"] = dealtype
    if description:
        props["description"] = description

    try:
        client = get_client()
        new_id = await client.create_object("deals", props)
        # Create associations
        if company_id:
            await client.create_association("deals", new_id, "companies", company_id)
        if contact_id:
            await client.create_association("deals", new_id, "contacts", contact_id)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to create deal: {exc}")
    except Exception as exc:
        return _error_result(f"Error creating deal: {exc}")

    _get_cache("Deal").clear()
    return await _refresh_with_created(
        await hs__get_deals(refresh=True), "deals", "Deal", "deals", new_id)


async def hs__update_deal(
    deal_id: str = "",
    dealname: str = "",
    amount: str = "",
    pipeline: str = "",
    dealstage: str = "",
    closedate: str = "",
    dealtype: str = "",
    description: str = "",
) -> types.CallToolResult:
    """Update an existing Deal in HubSpot CRM."""
    log.info("hs__update_deal", deal_id=deal_id)
    if not deal_id:
        return _error_result("deal_id is required.")

    props: dict[str, str] = {}
    if dealname:
        props["dealname"] = dealname
    if amount:
        props["amount"] = amount
    if pipeline:
        props["pipeline"] = pipeline
    if dealstage:
        props["dealstage"] = dealstage
    if closedate:
        props["closedate"] = _to_hs_date(closedate)
    if dealtype:
        props["dealtype"] = dealtype
    if description:
        props["description"] = description

    if not props:
        return _error_result("No fields to update.")

    try:
        client = get_client()
        await client.update_object("deals", deal_id, props)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to update deal: {exc}")
    except Exception as exc:
        return _error_result(f"Error updating deal: {exc}")

    _get_cache("Deal").clear()
    # Return only the saved record (single-record branch) so the widget can
    # patch that one row — avoids re-resolving associations for the whole list.
    return await hs__get_deals(deal_id=deal_id)


# ── Orders tools ──────────────────────────────────────────────────────────────

async def hs__get_orders(
    order_id: str = "",
    hs_order_name: str = "",
    hs_fulfillment_status: str = "",
    hs_payment_status: str = "",
    hs_currency_code: str = "",
    hs_total_price: str = "",
    hs_source_store: str = "",
    hs_total_price_min: str = "",
    hs_total_price_max: str = "",
    hs_closed_date: str = "",
    company_name: str = "",
    contact_name: str = "",
    deal_name: str = "",
    action: str = "",
    refresh: bool = False,
) -> types.CallToolResult:
    """Get orders from HubSpot CRM."""
    log.info("hs__get_orders", order_id=order_id, action=action,
             hs_order_name=hs_order_name, company_name=company_name, refresh=refresh)

    schema = _get_schema("Order")

    # ── Branch: blank create form ────────────────────────────────────────────
    if action == "create":
        prefill = {field["name"]: "" for field in schema["formFields"]}
        if hs_order_name:
            prefill["hs_order_name"] = hs_order_name
        if hs_total_price:
            prefill["hs_total_price"] = hs_total_price
        if hs_currency_code:
            prefill["hs_currency_code"] = hs_currency_code
        if hs_fulfillment_status:
            prefill["hs_fulfillment_status"] = hs_fulfillment_status
        if hs_payment_status:
            prefill["hs_payment_status"] = hs_payment_status
        if hs_source_store:
            prefill["hs_source_store"] = hs_source_store
        if company_name:
            prefill["company_name"] = company_name
        if contact_name:
            prefill["contact_name"] = contact_name
        if deal_name:
            prefill["deal_name"] = deal_name
        return types.CallToolResult(
            content=[TextContent(type="text", text="Opening order create form.")],
            structuredContent={
                "type": "form",
                "entity": "order",
                "mode": "create",
                "recordId": "",
                "prefill": prefill,
                "_schema": schema,
            },
        )

    # ── Branch: single record / edit form ────────────────────────────────────
    if order_id:
        try:
            client = get_client()
            props = [c["apiName"] for c in schema["columns"] + schema["hiddenColumns"] if not c["apiName"] in ("contact", "company", "deal")]
            record = await client.get_object("orders", order_id, props)
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except HubSpotAPIError as exc:
            return _error_result(f"Failed to fetch order: {exc}")
        except Exception as exc:
            return _error_result(f"Error fetching order: {exc}")

        if not record:
            return _error_result(f"Order {order_id} not found.")

        # Resolve FK associations
        try:
            co_ids = await client.get_associated_ids("orders", order_id, "companies")
            if co_ids:
                cos = await client.batch_read("companies", co_ids[:1], ["name"])
                record["company"] = cos[0].get("name", "") if cos else ""
            else:
                record["company"] = ""
        except Exception:
            record["company"] = ""

        try:
            ct_ids = await client.get_associated_ids("orders", order_id, "contacts")
            if ct_ids:
                cts = await client.batch_read("contacts", ct_ids[:1], ["firstname", "lastname"])
                record["contact"] = f"{cts[0].get('firstname', '')} {cts[0].get('lastname', '')}".strip() if cts else ""
            else:
                record["contact"] = ""
        except Exception:
            record["contact"] = ""

        try:
            deal_ids = await client.get_associated_ids("orders", order_id, "deals")
            if deal_ids:
                deals = await client.batch_read("deals", deal_ids[:1], ["dealname"])
                record["deal"] = deals[0].get("dealname", "") if deals else ""
            else:
                record["deal"] = ""
        except Exception:
            record["deal"] = ""

        if action == "edit":
            return types.CallToolResult(
                content=[TextContent(type="text", text=f"Opening edit form for order '{record.get('hs_order_name', '')}'.")],
                structuredContent={
                    "type": "form",
                    "entity": "order",
                    "mode": "edit",
                    "recordId": order_id,
                    "prefill": record,
                    "_schema": schema,
                },
            )

        return types.CallToolResult(
            content=[TextContent(type="text", text=f"Order: {record.get('hs_order_name', '')}.")],
            structuredContent={
                "type": "orders",
                "items": [record],
                "total": 1,
                "_schema": schema,
            },
        )

    # ── Branch: FK filter by company_name ────────────────────────────────────
    if company_name:
        try:
            client = get_client()
            co_id, suggestions = await _resolve_company(client, company_name)
            if not co_id:
                return _empty_list_on_not_found("orders", schema, _company_not_found_alert(company_name, suggestions))
            order_ids = await client.get_associated_ids("companies", co_id, "orders")
            if not order_ids:
                return types.CallToolResult(
                    content=[TextContent(type="text", text=f"No orders found for company '{company_name}'.")],
                    structuredContent={"type": "orders", "items": [], "total": 0, "_schema": schema},
                )
            native_props = [c["apiName"] for c in schema["columns"] if c["apiName"] not in ("contact", "company", "deal")]
            items = await client.batch_read("orders", order_ids, native_props)
            for item in items:
                item["company"] = company_name
                item["contact"] = ""
                item["deal"] = ""
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except Exception as exc:
            return _error_result(f"Error fetching orders by company: {exc}")

        cached_at = _cache_set(f"orders_co_{company_name}", "Order", items)
        return types.CallToolResult(
            content=[TextContent(type="text", text=f"Showing {len(items)} order(s) for '{company_name}'.")],
            structuredContent={"type": "orders", "items": items, "total": len(items), "_schema": schema, "_cache": {"hit": False, "cached_at": cached_at}},
        )

    # ── Branch: FK filter by contact_name ────────────────────────────────────
    if contact_name:
        try:
            client = get_client()
            ct_id, suggestions = await _resolve_contact(client, contact_name)
            if not ct_id:
                return _empty_list_on_not_found("orders", schema, _contact_not_found_alert(contact_name, suggestions))
            order_ids = await client.get_associated_ids("contacts", ct_id, "orders")
            if not order_ids:
                return types.CallToolResult(
                    content=[TextContent(type="text", text=f"No orders found for contact '{contact_name}'.")],
                    structuredContent={"type": "orders", "items": [], "total": 0, "_schema": schema},
                )
            native_props = [c["apiName"] for c in schema["columns"] if c["apiName"] not in ("contact", "company", "deal")]
            items = await client.batch_read("orders", order_ids, native_props)
            for item in items:
                item["contact"] = contact_name
                item["company"] = ""
                item["deal"] = ""
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except Exception as exc:
            return _error_result(f"Error fetching orders by contact: {exc}")

        cached_at = _cache_set(f"orders_ct_{contact_name}", "Order", items)
        return types.CallToolResult(
            content=[TextContent(type="text", text=f"Showing {len(items)} order(s) for '{contact_name}'.")],
            structuredContent={"type": "orders", "items": items, "total": len(items), "_schema": schema, "_cache": {"hit": False, "cached_at": cached_at}},
        )

    # ── Branch: FK filter by deal_name ───────────────────────────────────────
    if deal_name:
        try:
            client = get_client()
            d_id, suggestions = await _resolve_deal(client, deal_name)
            if not d_id:
                return _empty_list_on_not_found("orders", schema, _deal_not_found_alert(deal_name, suggestions))
            order_ids = await client.get_associated_ids("deals", d_id, "orders")
            if not order_ids:
                return types.CallToolResult(
                    content=[TextContent(type="text", text=f"No orders found for deal '{deal_name}'.")],
                    structuredContent={"type": "orders", "items": [], "total": 0, "_schema": schema},
                )
            native_props = [c["apiName"] for c in schema["columns"] if c["apiName"] not in ("contact", "company", "deal")]
            items = await client.batch_read("orders", order_ids, native_props)
            for item in items:
                item["deal"] = deal_name
                item["contact"] = ""
                item["company"] = ""
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except Exception as exc:
            return _error_result(f"Error fetching orders by deal: {exc}")

        cached_at = _cache_set(f"orders_dl_{deal_name}", "Order", items)
        return types.CallToolResult(
            content=[TextContent(type="text", text=f"Showing {len(items)} order(s) for '{deal_name}'.")],
            structuredContent={"type": "orders", "items": items, "total": len(items), "_schema": schema, "_cache": {"hit": False, "cached_at": cached_at}},
        )

    # ── Branch: list / filter ────────────────────────────────────────────────
    filter_params = {k: v for k, v in {
        "hs_order_name": hs_order_name,
        "hs_fulfillment_status": hs_fulfillment_status,
        "hs_payment_status": hs_payment_status,
        "hs_currency_code": hs_currency_code,
        "hs_total_price_min": hs_total_price_min,
        "hs_total_price_max": hs_total_price_max,
        "hs_closed_date": hs_closed_date,
    }.items() if v}
    filter_sig = _filter_signature(filter_params)
    cache_key = f"orders_{filter_sig}" if filter_sig else "orders_all"

    if not refresh:
        cached_items, cached_at = _cache_get(cache_key, "Order")
        if cached_items is not None:
            return types.CallToolResult(
                content=[TextContent(type="text", text=_list_summary("order(s)", cached_items, cache_hit=True))],
                structuredContent={"type": "orders", "items": cached_items, "total": len(cached_items), "_schema": schema, "_cache": {"hit": True, "cached_at": cached_at}},
            )

    try:
        client = get_client()
        filter_groups = _build_filter_groups("Order", filter_params) if filter_params else None
        native_props = [c["apiName"] for c in schema["columns"] if c["apiName"] not in ("contact", "company", "deal")]
        results = await client.search_objects("orders", native_props, filter_groups=filter_groups, limit=10)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to search orders: {exc}")
    except Exception as exc:
        return _error_result(f"Error searching orders: {exc}")

    # Resolve FK names for all orders using batch association + batch read
    # calls (a few round-trips total) instead of ~6 sequential calls per order.
    items = []
    for r in results:
        item = {p: r.get(p, "") or "" for p in native_props}
        item["id"] = r.get("id", "")
        item["company"] = ""
        item["contact"] = ""
        item["deal"] = ""
        items.append(item)

    order_ids = [i["id"] for i in items if i["id"]]
    if order_ids:
        try:
            co_map, ct_map, dl_map = await asyncio.gather(
                client.batch_get_associations("orders", "companies", order_ids),
                client.batch_get_associations("orders", "contacts", order_ids),
                client.batch_get_associations("orders", "deals", order_ids),
            )
            co_ids = list({v[0] for v in co_map.values() if v})
            ct_ids = list({v[0] for v in ct_map.values() if v})
            dl_ids = list({v[0] for v in dl_map.values() if v})
            cos, cts, ds = await asyncio.gather(
                client.batch_read("companies", co_ids, ["name"]) if co_ids else _empty_list(),
                client.batch_read("contacts", ct_ids, ["firstname", "lastname"]) if ct_ids else _empty_list(),
                client.batch_read("deals", dl_ids, ["dealname"]) if dl_ids else _empty_list(),
            )
            co_names = {c["id"]: c.get("name", "") for c in cos}
            ct_names = {c["id"]: f"{c.get('firstname', '')} {c.get('lastname', '')}".strip() for c in cts}
            dl_names = {d["id"]: d.get("dealname", "") for d in ds}
            for item in items:
                oid = item["id"]
                if co_map.get(oid):
                    item["company"] = co_names.get(co_map[oid][0], "")
                if ct_map.get(oid):
                    item["contact"] = ct_names.get(ct_map[oid][0], "")
                if dl_map.get(oid):
                    item["deal"] = dl_names.get(dl_map[oid][0], "")
        except Exception:
            pass

    cached_at = _cache_set(cache_key, "Order", items)
    return types.CallToolResult(
        content=[TextContent(type="text", text=_list_summary("order(s)", items))],
        structuredContent={"type": "orders", "items": items, "total": len(items), "_schema": schema, "_cache": {"hit": False, "cached_at": cached_at}},
    )


async def hs__create_order(
    hs_order_name: str = "",
    hs_total_price: str = "",
    hs_currency_code: str = "",
    hs_fulfillment_status: str = "",
    hs_payment_status: str = "",
    hs_source_store: str = "",
    company_name: str = "",
    contact_name: str = "",
    deal_name: str = "",
) -> types.CallToolResult:
    """Create a new Order in HubSpot CRM."""
    log.info("hs__create_order", hs_order_name=hs_order_name, company_name=company_name)
    if not hs_order_name:
        return _error_result("hs_order_name is required.")

    # Resolve FKs
    company_id: str | None = None
    if company_name:
        try:
            client = get_client()
            company_id, suggestions = await _resolve_company(client, company_name)
            if not company_id:
                return _company_not_found_alert(company_name, suggestions)
        except Exception as exc:
            return _error_result(f"Error resolving company: {exc}")

    contact_id: str | None = None
    if contact_name:
        try:
            client = get_client()
            contact_id, suggestions = await _resolve_contact(client, contact_name)
            if not contact_id:
                return _contact_not_found_alert(contact_name, suggestions)
        except Exception as exc:
            return _error_result(f"Error resolving contact: {exc}")

    deal_id: str | None = None
    if deal_name:
        try:
            client = get_client()
            deal_id, suggestions = await _resolve_deal(client, deal_name)
            if not deal_id:
                return _deal_not_found_alert(deal_name, suggestions)
        except Exception as exc:
            return _error_result(f"Error resolving deal: {exc}")

    props: dict[str, str] = {"hs_order_name": hs_order_name}
    if hs_total_price:
        props["hs_total_price"] = hs_total_price
    if hs_currency_code:
        props["hs_currency_code"] = hs_currency_code
    if hs_fulfillment_status:
        props["hs_fulfillment_status"] = hs_fulfillment_status
    if hs_payment_status:
        props["hs_payment_status"] = hs_payment_status
    if hs_source_store:
        props["hs_source_store"] = hs_source_store

    try:
        client = get_client()
        new_id = await client.create_object("orders", props)
        if company_id:
            await client.create_association("orders", new_id, "companies", company_id)
        if contact_id:
            await client.create_association("orders", new_id, "contacts", contact_id)
        if deal_id:
            await client.create_association("orders", new_id, "deals", deal_id)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to create order: {exc}")
    except Exception as exc:
        return _error_result(f"Error creating order: {exc}")

    _get_cache("Order").clear()
    return await _refresh_with_created(
        await hs__get_orders(refresh=True), "orders", "Order", "orders", new_id)


async def hs__update_order(
    order_id: str = "",
    hs_order_name: str = "",
    hs_total_price: str = "",
    hs_currency_code: str = "",
    hs_fulfillment_status: str = "",
    hs_payment_status: str = "",
    hs_source_store: str = "",
) -> types.CallToolResult:
    """Update an existing Order in HubSpot CRM."""
    log.info("hs__update_order", order_id=order_id)
    if not order_id:
        return _error_result("order_id is required.")

    props: dict[str, str] = {}
    if hs_order_name:
        props["hs_order_name"] = hs_order_name
    if hs_total_price:
        props["hs_total_price"] = hs_total_price
    if hs_currency_code:
        props["hs_currency_code"] = hs_currency_code
    if hs_fulfillment_status:
        props["hs_fulfillment_status"] = hs_fulfillment_status
    if hs_payment_status:
        props["hs_payment_status"] = hs_payment_status
    if hs_source_store:
        props["hs_source_store"] = hs_source_store

    if not props:
        return _error_result("No fields to update.")

    try:
        client = get_client()
        await client.update_object("orders", order_id, props)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to update order: {exc}")
    except Exception as exc:
        return _error_result(f"Error updating order: {exc}")

    _get_cache("Order").clear()
    # Return only the saved record (single-record branch) so the widget can
    # patch that one row — avoids re-resolving associations for the whole list.
    return await hs__get_orders(order_id=order_id)


# ── Products tools ────────────────────────────────────────────────────────────

async def hs__get_products(
    product_id: str = "",
    name: str = "",
    hs_sku: str = "",
    price: str = "",
    hs_status: str = "",
    hs_product_type: str = "",
    recurringbillingfrequency: str = "",
    price_min: str = "",
    price_max: str = "",
    action: str = "",
    refresh: bool = False,
) -> types.CallToolResult:
    """Get products. Branches: id+edit→form, id→list-of-one, filters→filtered, bare→top 10."""
    log.info("hs__get_products", product_id=product_id, action=action,
             name=name, hs_sku=hs_sku, hs_status=hs_status, hs_product_type=hs_product_type,
             recurringbillingfrequency=recurringbillingfrequency, refresh=refresh)

    cfg = _get_schema("Product")

    # Branch 1a — action="create" → blank create form
    if action == "create":
        prefill = {field["name"]: "" for field in cfg["formFields"]}
        if name:
            prefill["name"] = name
        if hs_sku:
            prefill["hs_sku"] = hs_sku
        if price:
            prefill["price"] = price
        if hs_status:
            prefill["hs_status"] = hs_status
        if hs_product_type:
            prefill["hs_product_type"] = hs_product_type
        if recurringbillingfrequency:
            prefill["recurringbillingfrequency"] = recurringbillingfrequency
        return types.CallToolResult(
            content=[TextContent(type="text", text="Opening create form for a new product.")],
            structuredContent={
                "type": "form", "entity": "product", "mode": "create",
                "recordId": "", "prefill": prefill,
                "_schema": cfg,
            },
        )

    # Branch 1b — id + action="edit"/"change" → prefilled edit form
    if product_id and action in ("edit", "change"):
        try:
            client = get_client()
            record = await client.get_object("products", product_id, _get_all_props("Product"))
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except HubSpotAPIError as exc:
            return _error_result(f"Product {product_id} not found: {exc}")
        except Exception as exc:
            return _error_result(f"Error looking up product: {exc}")

        prefill = {field["name"]: record.get(field["name"], "") or "" for field in cfg["formFields"]}
        return types.CallToolResult(
            content=[TextContent(type="text", text=f"Opening edit form for product: {record.get('name', product_id)}.")],
            structuredContent={
                "type": "form", "entity": "product", "mode": "edit",
                "recordId": record.get("id", product_id), "prefill": prefill,
                "_schema": cfg,
            },
        )

    # Branch 2 — id alone → list-of-one
    if product_id:
        try:
            client = get_client()
            record = await client.get_object("products", product_id, _get_list_props("Product"))
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except HubSpotAPIError as exc:
            return _error_result(f"Product {product_id} not found: {exc}")
        except Exception as exc:
            return _error_result(f"Error fetching product: {exc}")

        items = [record]
        return types.CallToolResult(
            content=[TextContent(type="text", text=_list_summary("product(s)", items))],
            structuredContent={
                "type": "products", "total": len(items), "items": items,
                "_schema": cfg, "_cache": {"hit": False, "cached_at": _now_iso()},
            },
        )

    # Branch 3 — filter-based or bare list
    filter_params = {
        "name": name, "hs_sku": hs_sku,
        "hs_product_type": hs_product_type, "hs_status": hs_status,
        "recurringbillingfrequency": recurringbillingfrequency,
        "price_min": price_min, "price_max": price_max,
    }
    filter_groups = _build_filter_groups("Product", filter_params)

    filter_sig = _filter_signature(filter_params)
    cache_key = f"products:{filter_sig}" if filter_sig else "products"
    if not refresh:
        cached_items, cached_at = _cache_get(cache_key, "Product")
        if cached_items is not None:
            return types.CallToolResult(
                content=[TextContent(type="text", text=_list_summary("product(s)", cached_items, cache_hit=True))],
                structuredContent={
                    "type": "products", "total": len(cached_items), "items": cached_items,
                    "_schema": cfg, "_cache": {"hit": True, "cached_at": cached_at},
                },
            )

    try:
        client = get_client()
        props = _get_list_props("Product")
        items = await client.search_objects("products", props, filter_groups=filter_groups, limit=10)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to fetch products: {exc}")
    except Exception as exc:
        return _error_result(f"Error fetching products: {exc}")

    cached_at = _cache_set(cache_key, "Product", items)
    return types.CallToolResult(
        content=[TextContent(type="text", text=_list_summary("product(s)", items))],
        structuredContent={
            "type": "products", "total": len(items), "items": items,
            "_schema": cfg, "_cache": {"hit": False, "cached_at": cached_at},
        },
    )


async def hs__create_product(
    name: str,
    hs_sku: str = "",
    price: str = "",
    hs_status: str = "",
    hs_product_type: str = "",
    recurringbillingfrequency: str = "",
    hs_recurring_billing_period: str = "",
    description: str = "",
) -> types.CallToolResult:
    """Create a new Product in HubSpot CRM. Requires name. Returns updated list."""
    log.info("hs__create_product", name=name, hs_sku=hs_sku, price=price,
             hs_status=hs_status, hs_product_type=hs_product_type)

    props: dict[str, Any] = {"name": name}
    if hs_sku:
        props["hs_sku"] = hs_sku
    if price:
        props["price"] = price
    if hs_status:
        props["hs_status"] = hs_status
    if hs_product_type:
        props["hs_product_type"] = hs_product_type
    if recurringbillingfrequency:
        props["recurringbillingfrequency"] = recurringbillingfrequency
    if hs_recurring_billing_period:
        props["hs_recurring_billing_period"] = _to_hs_duration(
            hs_recurring_billing_period, _term_unit_for_freq(recurringbillingfrequency))
    if description:
        props["description"] = description

    try:
        client = get_client()
        new_id = await client.create_object("products", props)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(_friendly_product_error(exc))
    except Exception as exc:
        return _error_result(f"Unexpected error creating product: {exc}")

    # Refresh list
    try:
        items = await client.search_objects("products", _get_list_props("Product"), limit=10)
        items = await _ensure_created(client, "products", "Product", new_id, items)
    except Exception:
        items = []

    cfg = _get_schema("Product")
    _cache_set("products", "Product", items)
    return types.CallToolResult(
        content=[TextContent(type="text", text=f"Product '{name}' created (Id: {new_id}).")],
        structuredContent={
            "type": "products", "total": len(items), "items": items,
            "_schema": cfg, "_createdId": new_id,
            "_cache": {"hit": False, "cached_at": _now_iso()},
        },
    )


async def hs__update_product(
    product_id: str,
    name: str = "",
    hs_sku: str = "",
    price: str = "",
    hs_status: str = "",
    hs_product_type: str = "",
    recurringbillingfrequency: str = "",
    hs_recurring_billing_period: str = "",
    description: str = "",
) -> types.CallToolResult:
    """Update an existing Product by id. Only provided fields are updated."""
    log.info("hs__update_product", product_id=product_id, name=name)

    if not product_id:
        return _error_result("product_id is required.")

    props: dict[str, Any] = {}
    if name:
        props["name"] = name
    if hs_sku:
        props["hs_sku"] = hs_sku
    if price:
        props["price"] = price
    if hs_status:
        props["hs_status"] = hs_status
    if hs_product_type:
        props["hs_product_type"] = hs_product_type
    if recurringbillingfrequency:
        props["recurringbillingfrequency"] = recurringbillingfrequency
    if description:
        props["description"] = description

    if not props and not hs_recurring_billing_period:
        return _error_result("No fields provided to update.")

    try:
        client = get_client()
        # Keep the term and billing frequency in the same unit family — HubSpot
        # rejects the save otherwise. Resolve the effective frequency (from this
        # update or the existing record) and (re)normalize the term to match,
        # even when only one of the two fields is being changed.
        if hs_recurring_billing_period or recurringbillingfrequency:
            existing = None
            if not recurringbillingfrequency or not hs_recurring_billing_period:
                existing = await client.get_object(
                    "products", product_id,
                    ["recurringbillingfrequency", "hs_recurring_billing_period"])
            freq = recurringbillingfrequency or (existing or {}).get("recurringbillingfrequency", "")
            term_src = hs_recurring_billing_period or (existing or {}).get("hs_recurring_billing_period", "")
            if term_src:
                props["hs_recurring_billing_period"] = _to_hs_duration(term_src, _term_unit_for_freq(freq))
        await client.update_object("products", product_id, props)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(_friendly_product_error(exc))
    except Exception as exc:
        return _error_result(f"Unexpected error updating product: {exc}")

    # Refresh list
    try:
        items = await client.search_objects("products", _get_list_props("Product"), limit=10)
    except Exception:
        items = []

    cfg = _get_schema("Product")
    _cache_set("products", "Product", items)
    return types.CallToolResult(
        content=[TextContent(type="text", text=f"Product {product_id} updated.")],
        structuredContent={
            "type": "products", "total": len(items), "items": items,
            "_schema": cfg, "_updatedId": product_id,
            "_cache": {"hit": False, "cached_at": _now_iso()},
        },
    )


# ── Activities tools ──────────────────────────────────────────────────────────

_ACTIVITY_SCHEMAS: dict[str, dict] = {
    "note": {
        "objectType": "notes",
        "columns": [
            {"apiName": "hs_note_body", "label": "Body"},
            {"apiName": "hs_timestamp", "label": "Date"},
        ],
        "hiddenColumns": [],
        "filterFields": {
            "hs_note_body": {"operator": "CONTAINS_TOKEN", "property": "hs_note_body"},
            "hs_timestamp": {"operator": "ON_DATE", "property": "hs_timestamp"},
        },
        "formFields": [
            {"name": "hs_note_body", "label": "Note Body", "multiline": True, "required": True},
        ],
    },
    "call": {
        "objectType": "calls",
        "columns": [
            {"apiName": "hs_call_body", "label": "Notes"},
            {"apiName": "hs_call_direction", "label": "Direction"},
            {"apiName": "hs_call_status", "label": "Status"},
            {"apiName": "hs_timestamp", "label": "Date"},
        ],
        "hiddenColumns": [
            {"apiName": "hs_call_duration", "label": "Duration (s)"},
        ],
        "filterFields": {
            "hs_call_direction": {"operator": "EQ", "property": "hs_call_direction"},
            "hs_call_status": {"operator": "EQ", "property": "hs_call_status"},
            "hs_call_body": {"operator": "CONTAINS_TOKEN", "property": "hs_call_body"},
            "hs_timestamp": {"operator": "ON_DATE", "property": "hs_timestamp"},
        },
        "formFields": [
            {"name": "hs_call_body", "label": "Call Notes", "multiline": True},
            {"name": "hs_call_direction", "label": "Direction", "required": True, "picklist": ["INBOUND", "OUTBOUND"]},
            {"name": "hs_call_status", "label": "Outcome", "picklist": ["COMPLETED", "BUSY", "NO_ANSWER", "FAILED", "CONNECTING", "CALLING_CRM_USER"]},
        ],
    },
    "task": {
        "objectType": "tasks",
        "columns": [
            {"apiName": "hs_task_subject", "label": "Subject"},
            {"apiName": "hs_task_status", "label": "Status"},
            {"apiName": "hs_task_priority", "label": "Priority"},
            {"apiName": "hs_timestamp", "label": "Due Date"},
        ],
        "hiddenColumns": [
            {"apiName": "hs_task_body", "label": "Body"},
        ],
        "filterFields": {
            "hs_task_status": {"operator": "EQ", "property": "hs_task_status"},
            "hs_task_priority": {"operator": "EQ", "property": "hs_task_priority"},
            "hs_task_subject": {"operator": "CONTAINS_TOKEN", "property": "hs_task_subject"},
        },
        "formFields": [
            {"name": "hs_task_subject", "label": "Subject", "required": True},
            {"name": "hs_task_body", "label": "Details", "multiline": True},
            {"name": "hs_task_status", "label": "Status", "picklist": ["NOT_STARTED", "IN_PROGRESS", "WAITING", "COMPLETED", "DEFERRED"]},
            {"name": "hs_task_priority", "label": "Priority", "picklist": ["HIGH", "MEDIUM", "LOW", "NONE"]},
            {"name": "hs_timestamp", "label": "Due Date", "inputType": "date"},
        ],
    },
    "meeting": {
        "objectType": "meetings",
        "columns": [
            {"apiName": "hs_meeting_title", "label": "Title"},
            {"apiName": "hs_meeting_outcome", "label": "Outcome"},
            {"apiName": "hs_meeting_start_time", "label": "Start"},
            {"apiName": "hs_meeting_end_time", "label": "End"},
        ],
        "hiddenColumns": [
            {"apiName": "hs_meeting_body", "label": "Description"},
        ],
        "filterFields": {
            "hs_meeting_outcome": {"operator": "EQ", "property": "hs_meeting_outcome"},
            "hs_meeting_title": {"operator": "CONTAINS_TOKEN", "property": "hs_meeting_title"},
            "hs_meeting_start_time": {"operator": "ON_DATE", "property": "hs_meeting_start_time"},
            "hs_meeting_end_time": {"operator": "ON_DATE", "property": "hs_meeting_end_time"},
        },
        "formFields": [
            {"name": "hs_meeting_title", "label": "Title", "required": True},
            {"name": "hs_meeting_body", "label": "Description", "multiline": True},
            {"name": "hs_meeting_start_time", "label": "Start Time", "inputType": "datetime-local"},
            {"name": "hs_meeting_end_time", "label": "End Time", "inputType": "datetime-local"},
            {"name": "hs_meeting_outcome", "label": "Outcome", "picklist": ["SCHEDULED", "COMPLETED", "RESCHEDULED", "NO_SHOW", "CANCELLED"]},
        ],
    },
    "email": {
        "objectType": "emails",
        "columns": [
            {"apiName": "hs_email_subject", "label": "Subject"},
            {"apiName": "hs_email_status", "label": "Status"},
            {"apiName": "hs_email_direction", "label": "Direction"},
            {"apiName": "hs_timestamp", "label": "Date"},
        ],
        "hiddenColumns": [
            {"apiName": "hs_email_text", "label": "Body"},
        ],
        "filterFields": {
            "hs_email_status": {"operator": "EQ", "property": "hs_email_status"},
            "hs_email_direction": {"operator": "EQ", "property": "hs_email_direction"},
            "hs_email_subject": {"operator": "CONTAINS_TOKEN", "property": "hs_email_subject"},
            "hs_timestamp": {"operator": "ON_DATE", "property": "hs_timestamp"},
        },
        "formFields": [
            {"name": "hs_email_subject", "label": "Subject", "required": True},
            {"name": "hs_email_direction", "label": "Direction", "picklist": ["EMAIL", "INCOMING_EMAIL", "FORWARDED_EMAIL"]},
            {"name": "hs_email_text", "label": "Details", "multiline": True, "fullWidth": True},
        ],
    },
}

_ACTIVITY_ASSOC_IDS: dict[tuple[str, str], int] = {
    ("notes", "companies"): 190,    ("notes", "contacts"): 202,    ("notes", "deals"): 214,
    ("calls", "companies"): 182,    ("calls", "contacts"): 194,    ("calls", "deals"): 206,
    ("tasks", "companies"): 192,    ("tasks", "contacts"): 204,    ("tasks", "deals"): 216,
    ("meetings", "companies"): 188, ("meetings", "contacts"): 200, ("meetings", "deals"): 212,
    ("emails", "companies"): 186,   ("emails", "contacts"): 198,   ("emails", "deals"): 210,
}

_VALID_ACTIVITY_TYPES = {"note", "call", "task", "meeting", "email"}
_VALID_ENTITY_TYPES = {"company", "contact", "deal"}

_ENTITY_RESOLVER: dict[str, tuple] = {
    "company": ("companies", _resolve_company, _company_not_found_alert),
    "contact": ("contacts", _resolve_contact, _contact_not_found_alert),
    "deal": ("deals", _resolve_deal, _deal_not_found_alert),
}

# ── Owner resolution ─────────────────────────────────────────────────────────

_owner_cache: TTLCache = TTLCache(maxsize=1, ttl=300)  # 5-min cache


async def _get_owners(client: Any) -> list[dict]:
    """Fetch owners with 5-min cache."""
    cached = _owner_cache.get("owners")
    if cached is not None:
        return cached
    owners = await client.get_owners()
    _owner_cache["owners"] = owners
    return owners


async def _resolve_owner(client: Any, name: str) -> tuple[str | None, list[str]]:
    """Resolve an owner by name. Returns (owner_id, suggestions)."""
    owners = await _get_owners(client)
    name_lower = name.lower()
    # Exact match first
    for o in owners:
        full = f"{o['firstName']} {o['lastName']}".strip()
        if full.lower() == name_lower:
            return o["id"], []
    # Partial match
    matches = []
    for o in owners:
        full = f"{o['firstName']} {o['lastName']}".strip()
        if name_lower in full.lower() or name_lower in o.get("email", "").lower():
            matches.append(o)
    if len(matches) == 1:
        return matches[0]["id"], []
    suggestions = [f"{o['firstName']} {o['lastName']}".strip() for o in (matches or owners)]
    return None, suggestions[:5]


def _activity_list_props(activity_type: str) -> list[str]:
    """Get property names for list view of an activity type."""
    cfg = _ACTIVITY_SCHEMAS[activity_type]
    props = [c["apiName"] for c in cfg["columns"] + cfg.get("hiddenColumns", [])]
    if "hubspot_owner_id" not in props:
        props.append("hubspot_owner_id")
    return props


async def _enrich_related_to(client: Any, obj_type: str, items: list[dict]) -> None:
    """Enrich activity items with _related_to field via batch association lookups."""
    if not items:
        return
    ids = [i["id"] for i in items if i.get("id")]
    if not ids:
        return

    # Batch-read associations to deals, contacts, companies — MOST SPECIFIC FIRST.
    # HubSpot auto-associates a contact's company (and a deal's contact/company),
    # so we must let the explicit, more-specific association win. Company is the
    # implicit/auto one, so it is checked LAST.
    related: dict[str, dict] = {}  # activity_id → {"type": ..., "name": ...}
    for entity_plural, entity_label in [("deals", "Deal"), ("contacts", "Contact"), ("companies", "Company")]:
        try:
            resp = await client._request(
                "POST",
                f"/crm/v4/associations/{obj_type}/{entity_plural}/batch/read",
                json_body={"inputs": [{"id": aid} for aid in ids]},
            )
            if not resp.is_success:
                continue
            results = resp.json().get("results", [])
            entity_ids_to_fetch: list[str] = []
            activity_to_entity: dict[str, str] = {}
            for r in results:
                from_id = str(r.get("from", {}).get("id", ""))
                to_list = r.get("to", [])
                if from_id and to_list and from_id not in related:
                    eid = str(to_list[0]["toObjectId"])
                    activity_to_entity[from_id] = eid
                    entity_ids_to_fetch.append(eid)
            if not entity_ids_to_fetch:
                continue
            # Batch-read entity names
            name_prop = "name" if entity_plural == "companies" else "dealname" if entity_plural == "deals" else "firstname"
            records = await client.batch_read(entity_plural, list(set(entity_ids_to_fetch)),
                                             ["firstname", "lastname"] if entity_plural == "contacts" else [name_prop])
            name_map: dict[str, str] = {}
            for rec in records:
                if entity_plural == "contacts":
                    name_map[rec["id"]] = f"{rec.get('firstname', '')} {rec.get('lastname', '')}".strip()
                else:
                    name_map[rec["id"]] = rec.get(name_prop, "") or rec.get("id", "")
            for act_id, ent_id in activity_to_entity.items():
                if act_id not in related and ent_id in name_map:
                    related[act_id] = {"type": entity_label, "name": name_map[ent_id]}
        except Exception:
            continue

    # Attach to items
    for item in items:
        rel = related.get(item.get("id", ""))
        if rel:
            item["_related_to"] = f"{rel['type']}: {rel['name']}"
        else:
            item["_related_to"] = ""


async def _owner_name_map(client: Any) -> dict[str, str]:
    """Map owner id (str) → 'First Last' from the cached owners list."""
    owners = await _get_owners(client)
    return {str(o["id"]): f"{o.get('firstName', '')} {o.get('lastName', '')}".strip() for o in owners}


async def _enrich_assigned_to(client: Any, items: list[dict]) -> None:
    """Enrich activity items with _assigned_to (owner display name).

    hubspot_owner_id is a numeric id; resolve it to a name for display. An
    activity with an owner id we can't resolve (e.g. deactivated user) shows
    '—'; one with no owner is left blank so the field is omitted."""
    if not items:
        return
    try:
        name_map = await _owner_name_map(client)
    except Exception:
        name_map = {}
    for item in items:
        oid = str(item.get("hubspot_owner_id") or "")
        item["_assigned_to"] = (name_map.get(oid, "—") if oid else "")


async def hs__get_activities(
    activity_type: str = "",
    activity_id: str = "",
    entity_type: str = "",
    entity_name: str = "",
    action: str = "",
    refresh: bool = False,
    # Shared timestamp (task due date, activity date)
    hs_timestamp: str = "",
    # Note fields
    hs_note_body: str = "",
    # Call fields
    hs_call_body: str = "",
    hs_call_direction: str = "",
    hs_call_status: str = "",
    # Task fields
    hs_task_subject: str = "",
    hs_task_body: str = "",
    hs_task_status: str = "",
    hs_task_priority: str = "",
    # Meeting fields
    hs_meeting_outcome: str = "",
    hs_meeting_title: str = "",
    hs_meeting_body: str = "",
    hs_meeting_start_time: str = "",
    hs_meeting_end_time: str = "",
    # Email fields
    hs_email_status: str = "",
    hs_email_direction: str = "",
    hs_email_subject: str = "",
    hs_email_text: str = "",
) -> types.CallToolResult:
    """Get activities (note/call/task/meeting/email). Requires activity_type.
    Branches: action=create→form, id+edit→form, id→single, entity_name→filtered, bare→top 10."""
    log.info("hs__get_activities", activity_type=activity_type, activity_id=activity_id,
             entity_type=entity_type, entity_name=entity_name, action=action, refresh=refresh)

    # Collect all filter kwargs into a dict
    kwargs: dict[str, str] = {}
    for k, v in [("hs_call_direction", hs_call_direction), ("hs_call_status", hs_call_status),
                 ("hs_task_subject", hs_task_subject), ("hs_task_status", hs_task_status),
                 ("hs_task_priority", hs_task_priority), ("hs_meeting_outcome", hs_meeting_outcome),
                 ("hs_meeting_title", hs_meeting_title),
                 ("hs_email_status", hs_email_status), ("hs_email_direction", hs_email_direction),
                 ("hs_email_subject", hs_email_subject),
                 # Body/content fields: hs_note_body & hs_call_body are now
                 # searchable (CONTAINS_TOKEN); hs_task_body & hs_meeting_body
                 # remain create-prefill only (not in any filterFields).
                 # Time fields: hs_timestamp (note/call/email date) and
                 # hs_meeting_start_time/hs_meeting_end_time are searchable
                 # (ON_DATE); for other types they are prefill only. Branch 4
                 # only turns a kwarg into a filter when it is in filterFields.
                 ("hs_timestamp", hs_timestamp), ("hs_note_body", hs_note_body),
                 ("hs_call_body", hs_call_body), ("hs_task_body", hs_task_body),
                 ("hs_meeting_body", hs_meeting_body),
                 ("hs_meeting_start_time", hs_meeting_start_time),
                 ("hs_meeting_end_time", hs_meeting_end_time),
                 ("hs_email_text", hs_email_text)]:
        if v:
            kwargs[k] = v

    if not activity_type or activity_type not in _VALID_ACTIVITY_TYPES:
        return _error_result(f"activity_type is required. Must be one of: {sorted(_VALID_ACTIVITY_TYPES)}.")

    cfg = _ACTIVITY_SCHEMAS[activity_type]
    obj_type = cfg["objectType"]

    # Branch 1a — action="create" → form (entity_type + entity_name for FK)
    if action == "create":
        prefill = {field["name"]: "" for field in cfg["formFields"]}
        # Pass through any kwargs that match form field names
        for field in cfg["formFields"]:
            if field["name"] in kwargs and kwargs[field["name"]]:
                prefill[field["name"]] = kwargs[field["name"]]
        return types.CallToolResult(
            content=[TextContent(type="text", text=f"Opening create form for a new {activity_type}.")],
            structuredContent={
                "type": "activity_form", "activity_type": activity_type,
                "entity_type": entity_type or "", "entity_name": entity_name or "",
                "mode": "create", "recordId": "", "prefill": prefill,
                "_schema": cfg,
            },
        )

    # Branch 1b — id + action="edit" → prefilled edit form
    if activity_id and action in ("edit", "change"):
        try:
            client = get_client()
            record = await client.get_object(obj_type, activity_id, _activity_list_props(activity_type))
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except HubSpotAPIError as exc:
            return _error_result(f"{activity_type} {activity_id} not found: {exc}")
        except Exception as exc:
            return _error_result(f"Error looking up {activity_type}: {exc}")

        prefill = {field["name"]: record.get(field["name"], "") or "" for field in cfg["formFields"]}
        oid = str(record.get("hubspot_owner_id") or "")
        if oid:
            try:
                prefill["_owner_name"] = (await _owner_name_map(client)).get(oid, "")
            except Exception:
                prefill["_owner_name"] = ""
        return types.CallToolResult(
            content=[TextContent(type="text", text=f"Opening edit form for {activity_type} {activity_id}.")],
            structuredContent={
                "type": "activity_form", "activity_type": activity_type,
                "entity_type": "", "entity_name": "",
                "mode": "edit", "recordId": activity_id, "prefill": prefill,
                "_schema": cfg,
            },
        )

    # Branch 2 — id alone → single record view
    if activity_id:
        try:
            client = get_client()
            record = await client.get_object(obj_type, activity_id, _activity_list_props(activity_type))
        except HubSpotAuthError as exc:
            return _error_result(f"HubSpot authentication failed: {exc}")
        except HubSpotAPIError as exc:
            return _error_result(f"{activity_type} {activity_id} not found: {exc}")
        except Exception as exc:
            return _error_result(f"Error fetching {activity_type}: {exc}")

        items = [record]
        try:
            await _enrich_related_to(client, obj_type, items)
            await _enrich_assigned_to(client, items)
        except Exception as exc:
            log.warning("enrich single-view failed", error=str(exc))
        return types.CallToolResult(
            content=[TextContent(type="text", text=f"1 {activity_type}(s).")],
            structuredContent={
                "type": "activities", "activity_type": activity_type,
                "total": 1, "items": items,
                "_schema": cfg, "_cache": {"hit": False, "cached_at": _now_iso()},
            },
        )

    # Branch 3 — entity_name filter (resolve FK → get associations → batch read)
    if entity_name and entity_type:
        if entity_type not in _VALID_ENTITY_TYPES:
            return _error_result(f"entity_type must be one of: {sorted(_VALID_ENTITY_TYPES)}.")
        plural, resolver, alert_fn = _ENTITY_RESOLVER[entity_type]
        try:
            client = get_client()
            entity_id, suggestions = await resolver(client, entity_name)
        except Exception as exc:
            return _error_result(f"Error resolving {entity_type}: {exc}")
        if not entity_id:
            # Do NOT render a separate alert widget. Show the correct (empty)
            # entity widget and surface the "not found / did you mean" text in
            # chat, per instructions.
            alert = alert_fn(entity_name, suggestions)
            notice = alert.content[0].text if alert.content else f"{entity_type} '{entity_name}' not found."
            return types.CallToolResult(
                content=[TextContent(type="text", text=notice)],
                structuredContent={
                    "type": "activities", "activity_type": activity_type,
                    "total": 0, "items": [],
                    "_schema": cfg, "_cache": {"hit": False, "cached_at": _now_iso()},
                },
            )

        # Get associated activity IDs
        try:
            assoc_ids = await client.get_associated_ids(plural, entity_id, obj_type)
            if assoc_ids:
                records = await client.batch_read(obj_type, assoc_ids[:10], _activity_list_props(activity_type))
            else:
                records = []
        except Exception as exc:
            return _error_result(f"Error fetching {activity_type}s for {entity_type}: {exc}")

        items = [{"id": r.get("id", ""), **r} for r in records]
        # Enrich with Related To (same as Branch 4 — the FK-filtered path must
        # also populate _related_to so the widget's "Related To" column renders).
        try:
            await _enrich_related_to(client, obj_type, items)
            await _enrich_assigned_to(client, items)
        except Exception as exc:
            log.warning("enrich_related_to failed", error=str(exc))
        return types.CallToolResult(
            content=[TextContent(type="text", text=f"{len(items)} {activity_type}(s) for {entity_name}.")],
            structuredContent={
                "type": "activities", "activity_type": activity_type,
                "total": len(items), "items": items,
                "_schema": cfg, "_cache": {"hit": False, "cached_at": _now_iso()},
            },
        )

    # Branch 4 — filter-based or bare search
    filter_params = {k: v for k, v in kwargs.items() if v and k in cfg.get("filterFields", {})}
    filter_defs = cfg.get("filterFields", {})
    filters = []
    for param_name, value in filter_params.items():
        fdef = filter_defs.get(param_name)
        if fdef:
            filters.extend(_expand_filter(fdef, value))
    filter_groups = [{"filters": filters}] if filters else None

    try:
        client = get_client()
        props = _activity_list_props(activity_type)
        items = await client.search_objects(obj_type, props, filter_groups=filter_groups, limit=10)
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to fetch {activity_type}s: {exc}")
    except Exception as exc:
        return _error_result(f"Error fetching {activity_type}s: {exc}")

    # Enrich with Related To
    try:
        await _enrich_related_to(client, obj_type, items)
        await _enrich_assigned_to(client, items)
    except Exception as exc:
        log.warning("enrich_related_to failed", error=str(exc))

    return types.CallToolResult(
        content=[TextContent(type="text", text=f"{len(items)} {activity_type}(s).")],
        structuredContent={
            "type": "activities", "activity_type": activity_type,
            "total": len(items), "items": items,
            "_schema": cfg, "_cache": {"hit": False, "cached_at": _now_iso()},
        },
    )


async def hs__create_activity(
    activity_type: str,
    entity_type: str = "",
    entity_name: str = "",
    owner_name: str = "",
    # Shared timestamp (task due date, activity date)
    hs_timestamp: str = "",
    # Note fields
    hs_note_body: str = "",
    # Call fields
    hs_call_body: str = "",
    hs_call_direction: str = "",
    hs_call_status: str = "",
    # Task fields
    hs_task_subject: str = "",
    hs_task_body: str = "",
    hs_task_status: str = "",
    hs_task_priority: str = "",
    # Meeting fields
    hs_meeting_title: str = "",
    hs_meeting_body: str = "",
    hs_meeting_start_time: str = "",
    hs_meeting_end_time: str = "",
    hs_meeting_outcome: str = "",
    # Email fields
    hs_email_subject: str = "",
    hs_email_text: str = "",
    hs_email_direction: str = "",
    hs_email_status: str = "",
) -> types.CallToolResult:
    """Create an activity (note/call/task/meeting/email) and associate it with an entity."""
    log.info("hs__create_activity", activity_type=activity_type,
             entity_type=entity_type, entity_name=entity_name)

    if not activity_type or activity_type not in _VALID_ACTIVITY_TYPES:
        return _error_result(f"activity_type is required. Must be one of: {sorted(_VALID_ACTIVITY_TYPES)}.")

    # Collect all field values into kwargs dict
    kwargs: dict[str, str] = {}
    for k, v in [("hs_timestamp", hs_timestamp),
                 ("hs_note_body", hs_note_body), ("hs_call_body", hs_call_body),
                 ("hs_call_direction", hs_call_direction), ("hs_call_status", hs_call_status),
                 ("hs_task_subject", hs_task_subject), ("hs_task_body", hs_task_body),
                 ("hs_task_status", hs_task_status), ("hs_task_priority", hs_task_priority),
                 ("hs_meeting_title", hs_meeting_title), ("hs_meeting_body", hs_meeting_body),
                 ("hs_meeting_start_time", hs_meeting_start_time), ("hs_meeting_end_time", hs_meeting_end_time),
                 ("hs_meeting_outcome", hs_meeting_outcome), ("hs_email_subject", hs_email_subject),
                 ("hs_email_text", hs_email_text), ("hs_email_direction", hs_email_direction),
                 ("hs_email_status", hs_email_status)]:
        if v:
            kwargs[k] = v

    cfg = _ACTIVITY_SCHEMAS[activity_type]
    obj_type = cfg["objectType"]

    # Build properties from kwargs matching form fields
    props: dict[str, Any] = {}
    for field in cfg["formFields"]:
        val = kwargs.get(field["name"], "")
        if val:
            if field.get("inputType") in ("date", "datetime-local"):
                val = _to_hs_date(val)
            props[field["name"]] = val

    # Ensure required fields
    required_fields = [f["name"] for f in cfg["formFields"] if f.get("required")]
    for rf in required_fields:
        if not props.get(rf):
            return _error_result(f"'{rf}' is required for {activity_type}.")

    # Auto-set timestamp only if user didn't provide one
    if "hs_timestamp" not in props:
        props["hs_timestamp"] = _now_iso()

    # Auto-set email status to DRAFT on create
    if activity_type == "email":
        props["hs_email_status"] = "DRAFT"

    # Resolve FK entity for association
    associations: list[dict] = []
    if entity_name and entity_type:
        if entity_type not in _VALID_ENTITY_TYPES:
            return _error_result(f"entity_type must be one of: {sorted(_VALID_ENTITY_TYPES)}.")
        plural, resolver, alert_fn = _ENTITY_RESOLVER[entity_type]
        try:
            client = get_client()
            entity_id, suggestions = await resolver(client, entity_name)
        except Exception as exc:
            return _error_result(f"Error resolving {entity_type}: {exc}")
        if not entity_id:
            return alert_fn(entity_name, suggestions)

        assoc_type_id = _ACTIVITY_ASSOC_IDS.get((obj_type, plural))
        if assoc_type_id:
            associations.append({
                "to": {"id": entity_id},
                "types": [{"associationCategory": "HUBSPOT_DEFINED", "associationTypeId": assoc_type_id}],
            })

    # Resolve owner name → owner ID
    if owner_name:
        try:
            client = get_client()
            owner_id, suggestions = await _resolve_owner(client, owner_name)
        except Exception as exc:
            return _error_result(f"Error resolving owner: {exc}")
        if not owner_id:
            return types.CallToolResult(
                content=[TextContent(type="text", text=f"Owner '{owner_name}' not found.")],
                structuredContent={
                    "type": "alert", "style": "fk",
                    "message": f"No exact match for owner '{owner_name}'.",
                    "suggestions": suggestions,
                    "systemName": "HubSpot",
                },
            )
        props["hubspot_owner_id"] = owner_id

    # Create the activity
    try:
        client = get_client()
        body: dict[str, Any] = {"properties": props}
        if associations:
            body["associations"] = associations
        # Use raw _request since create_object doesn't support associations
        resp = await client._request("POST", f"/crm/v3/objects/{obj_type}", json_body=body)
        client._raise_for_error(resp, f"create {obj_type}")
        new_id = resp.json()["id"]
    except HubSpotAuthError as exc:
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        return _error_result(f"Failed to create {activity_type}: {exc}")
    except Exception as exc:
        return _error_result(f"Unexpected error creating {activity_type}: {exc}")

    # Refresh list
    try:
        items = await client.search_objects(obj_type, _activity_list_props(activity_type), limit=10)
        await _enrich_related_to(client, obj_type, items)
        await _enrich_assigned_to(client, items)
    except Exception:
        items = []

    return types.CallToolResult(
        content=[TextContent(type="text", text=f"{activity_type.title()} created (Id: {new_id}).")],
        structuredContent={
            "type": "activities", "activity_type": activity_type,
            "total": len(items), "items": items,
            "_schema": cfg, "_createdId": new_id,
            "_cache": {"hit": False, "cached_at": _now_iso()},
        },
    )


async def hs__update_activity(
    activity_type: str,
    activity_id: str,
    owner_name: str = "",
    # Shared timestamp (task due date, activity date)
    hs_timestamp: str = "",
    # Note fields
    hs_note_body: str = "",
    # Call fields
    hs_call_body: str = "",
    hs_call_direction: str = "",
    hs_call_status: str = "",
    # Task fields
    hs_task_subject: str = "",
    hs_task_body: str = "",
    hs_task_status: str = "",
    hs_task_priority: str = "",
    # Meeting fields
    hs_meeting_title: str = "",
    hs_meeting_body: str = "",
    hs_meeting_start_time: str = "",
    hs_meeting_end_time: str = "",
    hs_meeting_outcome: str = "",
    # Email fields
    hs_email_subject: str = "",
    hs_email_text: str = "",
    hs_email_direction: str = "",
    hs_email_status: str = "",
) -> types.CallToolResult:
    """Update an existing activity by id. Only provided fields are updated."""
    log.info("hs__update_activity", activity_type=activity_type, activity_id=activity_id)

    if not activity_type or activity_type not in _VALID_ACTIVITY_TYPES:
        return _error_result(f"activity_type is required. Must be one of: {sorted(_VALID_ACTIVITY_TYPES)}.")
    if not activity_id:
        return _error_result("activity_id is required.")

    cfg = _ACTIVITY_SCHEMAS[activity_type]
    obj_type = cfg["objectType"]

    # Collect all field values into kwargs dict
    kwargs: dict[str, str] = {}
    for k, v in [("hs_timestamp", hs_timestamp),
                 ("hs_note_body", hs_note_body), ("hs_call_body", hs_call_body),
                 ("hs_call_direction", hs_call_direction), ("hs_call_status", hs_call_status),
                 ("hs_task_subject", hs_task_subject), ("hs_task_body", hs_task_body),
                 ("hs_task_status", hs_task_status), ("hs_task_priority", hs_task_priority),
                 ("hs_meeting_title", hs_meeting_title), ("hs_meeting_body", hs_meeting_body),
                 ("hs_meeting_start_time", hs_meeting_start_time), ("hs_meeting_end_time", hs_meeting_end_time),
                 ("hs_meeting_outcome", hs_meeting_outcome), ("hs_email_subject", hs_email_subject),
                 ("hs_email_text", hs_email_text), ("hs_email_direction", hs_email_direction),
                 ("hs_email_status", hs_email_status)]:
        if v:
            kwargs[k] = v

    # Build properties from kwargs matching form fields
    props: dict[str, Any] = {}
    valid_fields = {f["name"] for f in cfg["formFields"]}
    date_fields = {f["name"] for f in cfg["formFields"] if f.get("inputType") in ("date", "datetime-local")}
    for k, v in kwargs.items():
        if k in valid_fields and v:
            props[k] = _to_hs_date(v) if k in date_fields else v

    # Resolve owner name → owner ID
    if owner_name:
        try:
            client = get_client()
            owner_id, suggestions = await _resolve_owner(client, owner_name)
        except Exception as exc:
            return _error_result(f"Error resolving owner: {exc}")
        if not owner_id:
            return types.CallToolResult(
                content=[TextContent(type="text", text=f"Owner '{owner_name}' not found.")],
                structuredContent={
                    "type": "alert", "style": "fk",
                    "message": f"No exact match for owner '{owner_name}'.",
                    "suggestions": suggestions,
                    "systemName": "HubSpot",
                },
            )
        props["hubspot_owner_id"] = owner_id

    if not props:
        return _error_result("No fields provided to update.")

    log.info("hs__update_activity sending props", props=props)

    try:
        client = get_client()
        await client.update_object(obj_type, activity_id, props)
    except HubSpotAuthError as exc:
        log.error("Auth error updating activity", activity_type=activity_type, activity_id=activity_id, error=str(exc))
        return _error_result(f"HubSpot authentication failed: {exc}")
    except HubSpotAPIError as exc:
        log.error("API error updating activity", activity_type=activity_type, activity_id=activity_id, error=str(exc))
        return _error_result(f"Failed to update {activity_type}: {exc}")
    except Exception as exc:
        log.error("Unexpected error updating activity", activity_type=activity_type, activity_id=activity_id, error=str(exc))
        return _error_result(f"Error updating {activity_type}: {exc}")

    # Refresh list
    try:
        items = await client.search_objects(obj_type, _activity_list_props(activity_type), limit=10)
        # Enrich with Related To — parity with hs__get_activities so the refreshed
        # list (and the edit popup that reads item._related_to) keeps the column.
        await _enrich_related_to(client, obj_type, items)
        await _enrich_assigned_to(client, items)
    except Exception:
        items = []

    return types.CallToolResult(
        content=[TextContent(type="text", text=f"{activity_type.title()} {activity_id} updated.")],
        structuredContent={
            "type": "activities", "activity_type": activity_type,
            "total": len(items), "items": items,
            "_schema": cfg, "_updatedId": activity_id,
            "_cache": {"hit": False, "cached_at": _now_iso()},
        },
    )


# ── Tool specs (registered by server) ────────────────────────────────────────

TOOL_SPECS: list[dict] = [
    {
        "name": "hs__get_companies",
        "description": (
            "Get companies from HubSpot CRM (10 most recent). "
            "Pass company_id to view one record; add action='edit' to open the edit form. "
            "Filters: name (text search), domain (text search), "
            "type (PROSPECT, PARTNER, RESELLER, VENDOR, OTHER), "
            "lifecyclestage (subscriber, lead, marketingqualifiedlead, salesqualifiedlead, "
            "opportunity, customer, evangelist, other), city, country."
        ),
        "handler": hs__get_companies,
    },
    {
        "name": "hs__create_company",
        "description": (
            "Create a new Company in HubSpot CRM. Requires: name. "
            "Optional: domain, type (PROSPECT/PARTNER/RESELLER/VENDOR/OTHER), "
            "lifecyclestage (subscriber/lead/marketingqualifiedlead/salesqualifiedlead/"
            "opportunity/customer/evangelist/other), city, phone, country, description."
        ),
        "handler": hs__create_company,
    },
    {
        "name": "hs__update_company",
        "description": (
            "Update an existing Company in HubSpot CRM by its record Id. "
            "Only fields provided will be updated. "
            "Fields: name, domain, type, lifecyclestage, city, phone, country, description."
        ),
        "handler": hs__update_company,
    },
    {
        "name": "hs__get_associations",
        "description": (
            "Get records associated to an entity in HubSpot CRM. "
            "Required: entity_type (companies or contacts), entity_id, "
            "association_type (contacts, deals, tickets, or companies). "
            "Returns fields relevant to the target type."
        ),
        "handler": hs__get_associations,
    },
    {
        "name": "hs__get_contacts",
        "description": (
            "Get contacts from HubSpot CRM (10 most recent). "
            "Pass contact_id to view one record; add action='edit' to open the edit form; "
            "action='create' to open a blank create form. "
            "Filters: firstname, lastname, email, jobtitle, city, phone, "
            "company_name (FK — searches all associations), "
            "lifecyclestage (subscriber/lead/marketingqualifiedlead/salesqualifiedlead/"
            "opportunity/customer/evangelist/other). "
            "With action='create', prefills the form from any of: firstname, lastname, "
            "email, phone, jobtitle, lifecyclestage, city, company_name."
        ),
        "handler": hs__get_contacts,
    },
    {
        "name": "hs__create_contact",
        "description": (
            "Create a new Contact in HubSpot CRM. Requires: firstname, lastname, email. "
            "Optional: phone, jobtitle, lifecyclestage, city, company_name (associates to matching company)."
        ),
        "handler": hs__create_contact,
    },
    {
        "name": "hs__update_contact",
        "description": (
            "Update an existing Contact in HubSpot CRM by its record Id. "
            "Only fields provided will be updated. "
            "Fields: firstname, lastname, email, phone, jobtitle, lifecyclestage, city."
        ),
        "handler": hs__update_contact,
    },
    {
        "name": "hs__get_deals",
        "description": (
            "Get deals from HubSpot CRM (10 most recent). "
            "Pass deal_id to view one record; add action='edit' to open the edit form; "
            "action='create' to open a blank create form. "
            "Filters: dealname (text search), dealstage (stage ID or closedwon/closedlost), "
            "pipeline (default), dealtype (newbusiness/existingbusiness), "
            "amount_min / amount_max (numeric amount range, >= / <=), "
            "closedate (exact calendar day, e.g. 2026-08-31), "
            "company_name (FK — finds deals associated to that company). "
            "With action='create', prefills the form from any of: dealname, amount, "
            "closedate (YYYY-MM-DD), dealstage, pipeline, dealtype, company_name."
        ),
        "handler": hs__get_deals,
    },
    {
        "name": "hs__create_deal",
        "description": (
            "Create a new Deal in HubSpot CRM. Required: dealname, dealstage, pipeline. "
            "Optional: amount, closedate (ISO date), dealtype (newbusiness/existingbusiness), "
            "description, company_name (associates to matching company), "
            "contact_name (associates to matching contact)."
        ),
        "handler": hs__create_deal,
    },
    {
        "name": "hs__update_deal",
        "description": (
            "Update an existing Deal in HubSpot CRM by its record Id. "
            "Only fields provided will be updated. "
            "Fields: dealname, amount, pipeline, dealstage, closedate, dealtype, description."
        ),
        "handler": hs__update_deal,
    },
    {
        "name": "hs__get_orders",
        "description": (
            "Get orders from HubSpot CRM (10 most recent). "
            "Pass order_id to view one record; add action='edit' to open the edit form; "
            "action='create' to open a blank create form. "
            "Filters: hs_order_name (text search), hs_fulfillment_status, hs_payment_status, "
            "hs_currency_code, hs_total_price_min / hs_total_price_max (numeric total range — "
            "e.g. 'orders over 5000' -> hs_total_price_min=5000), "
            "hs_closed_date (exact calendar day, e.g. 2026-08-31), "
            "company_name (FK), contact_name (FK), deal_name (FK)."
        ),
        "handler": hs__get_orders,
    },
    {
        "name": "hs__create_order",
        "description": (
            "Create a new Order in HubSpot CRM. Required: hs_order_name. "
            "Optional: hs_total_price, hs_currency_code, hs_fulfillment_status, "
            "hs_payment_status, hs_source_store, "
            "company_name (associates to company), contact_name (associates to contact), "
            "deal_name (associates to deal)."
        ),
        "handler": hs__create_order,
    },
    {
        "name": "hs__update_order",
        "description": (
            "Update an existing Order in HubSpot CRM by its record Id. "
            "Only fields provided will be updated. "
            "Fields: hs_order_name, hs_total_price, hs_currency_code, "
            "hs_fulfillment_status, hs_payment_status, hs_source_store."
        ),
        "handler": hs__update_order,
    },
    {
        "name": "hs__get_products",
        "description": (
            "Get products from HubSpot CRM (10 most recent). "
            "Pass product_id to view one record; add action='edit' to open the edit form; "
            "action='create' to open a blank create form. "
            "Filters: name (text search), hs_sku (text search), "
            "price_min / price_max (numeric price range, >= / <=), "
            "hs_product_type (inventory/non_inventory/service), "
            "hs_status (active/inactive), recurringbillingfrequency (weekly/biweekly/monthly/"
            "quarterly/per_six_months/annually/per_two_years/per_three_years/per_four_years/per_five_years)."
        ),
        "handler": hs__get_products,
    },
    {
        "name": "hs__create_product",
        "description": (
            "Create a new Product in HubSpot CRM. Required: name. "
            "Optional: hs_sku, price, hs_status (active/inactive), "
            "hs_product_type (inventory/non_inventory/service), "
            "recurringbillingfrequency (weekly/biweekly/monthly/quarterly/per_six_months/"
            "annually/per_two_years/per_three_years/per_four_years/per_five_years), "
            "hs_recurring_billing_period (term, e.g. '12 months' or '90 days'), description."
        ),
        "handler": hs__create_product,
    },
    {
        "name": "hs__update_product",
        "description": (
            "Update an existing Product in HubSpot CRM by its record Id. "
            "Only fields provided will be updated. "
            "Fields: name, hs_sku, price, hs_status, hs_product_type, "
            "recurringbillingfrequency, hs_recurring_billing_period (term, e.g. '12 months'), description."
        ),
        "handler": hs__update_product,
    },
    {
        "name": "hs__get_activities",
        "description": (
            "Get activities from HubSpot CRM. REQUIRED: activity_type (note/call/task/meeting/email). "
            "Pass activity_id to view one; add action='edit' to open edit form; action='create' for new. "
            "Filter by entity: entity_type (company/contact/deal) + entity_name. "
            "Filter by fields: note(hs_note_body, hs_timestamp), "
            "call(hs_call_direction, hs_call_status, hs_call_body, hs_timestamp), "
            "task(hs_task_subject, hs_task_status, hs_task_priority), "
            "meeting(hs_meeting_outcome, hs_meeting_title, hs_meeting_start_time, hs_meeting_end_time), "
            "email(hs_email_status, hs_email_direction, hs_email_subject, hs_timestamp). "
            "Body fields (hs_note_body, hs_call_body) match text as a substring (\"notes/calls mentioning X\"); "
            "date fields (hs_timestamp, hs_meeting_start_time, hs_meeting_end_time) match one exact calendar day (YYYY-MM-DD); "
            "open-ended ranges (before/after/between) are not supported. "
            "On action='create', these same fields prefill the form, plus form-only content: "
            "task(hs_task_body), meeting(hs_meeting_body), email(hs_email_text)."
        ),
        "handler": hs__get_activities,
    },
    {
        "name": "hs__create_activity",
        "description": (
            "Create an activity in HubSpot CRM. REQUIRED: activity_type (note/call/task/meeting/email). "
            "Optional: entity_type (company/contact/deal) + entity_name to associate. "
            "Note fields: hs_note_body. Call: hs_call_body, hs_call_direction, hs_call_status. "
            "Task: hs_task_subject, hs_task_body, hs_task_status, hs_task_priority. "
            "Meeting: hs_meeting_title, hs_meeting_body, hs_meeting_start_time, hs_meeting_end_time, hs_meeting_outcome. "
            "Email: hs_email_subject, hs_email_text, hs_email_direction, hs_email_status."
        ),
        "handler": hs__create_activity,
    },
    {
        "name": "hs__update_activity",
        "description": (
            "Update an existing activity in HubSpot CRM. REQUIRED: activity_type + activity_id. "
            "Only provided fields are updated. Fields depend on activity_type."
        ),
        "handler": hs__update_activity,
    },
]


# ── Prompt specs ──────────────────────────────────────────────────────────────

PROMPT_SPECS: list[dict] = []
